import { config } from 'dotenv';
config();

import '@/ai/flows/generate-family-discussion-points.ts';