'use server';

/**
 * @fileOverview Generates tailored family discussion points based on completed lessons,
 * key comprehension areas, and shared family values.
 *
 * - generateFamilyDiscussionPoints - A function to generate discussion prompts.
 * - GenerateFamilyDiscussionPointsInput - The input type for the function.
 * - GenerateFamilyDiscussionPointsOutput - The return type for the function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateFamilyDiscussionPointsInputSchema = z.object({
  lessonSummary: z
    .string()
    .describe('A summary of the lesson completed by the child.'),
  keyAreas: z
    .string()
    .describe(
      'Key areas of comprehension identified from the AI analysis of the lesson.'
    ),
  familyValues: z
    .string()
    .describe('A list of shared family values to align the discussion with.'),
});
export type GenerateFamilyDiscussionPointsInput = z.infer<
  typeof GenerateFamilyDiscussionPointsInputSchema
>;

const GenerateFamilyDiscussionPointsOutputSchema = z.object({
  discussionPoints: z
    .string()
    .describe('AI-generated discussion points for the family.'),
});
export type GenerateFamilyDiscussionPointsOutput = z.infer<
  typeof GenerateFamilyDiscussionPointsOutputSchema
>;

export async function generateFamilyDiscussionPoints(
  input: GenerateFamilyDiscussionPointsInput
): Promise<GenerateFamilyDiscussionPointsOutput> {
  return generateFamilyDiscussionPointsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generateFamilyDiscussionPointsPrompt',
  input: {schema: GenerateFamilyDiscussionPointsInputSchema},
  output: {schema: GenerateFamilyDiscussionPointsOutputSchema},
  prompt: `You are an AI assistant designed to generate engaging and meaningful family discussion points based on a child's completed lesson, key comprehension areas, and shared family values.

  Lesson Summary: {{{lessonSummary}}}
  Key Areas Identified: {{{keyAreas}}}
  Family Values: {{{familyValues}}}

  Generate discussion points that encourage thoughtful conversation, promote character development, and align with the family's values. The discussion points should be open-ended and encourage the child to reflect on what they learned and how it applies to their life.

  Output:
  Discussion Points:`,
});

const generateFamilyDiscussionPointsFlow = ai.defineFlow(
  {
    name: 'generateFamilyDiscussionPointsFlow',
    inputSchema: GenerateFamilyDiscussionPointsInputSchema,
    outputSchema: GenerateFamilyDiscussionPointsOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
