'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Users, BookOpen, Activity } from "lucide-react";
import { ChartContainer, ChartTooltip, ChartTooltipContent, ChartConfig } from '@/components/ui/chart';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, ResponsiveContainer } from 'recharts';
import { Badge } from "@/components/ui/badge";

const recentSignups = [
    { name: "Liam Johnson", email: "liam@example.com", role: "Student", date: "2024-05-20", avatar: "https://placehold.co/40x40.png?text=LJ" },
    { name: "Olivia Williams", email: "olivia@example.com", role: "Parent", date: "2024-05-20", avatar: "https://placehold.co/40x40.png?text=OW" },
    { name: "Noah Brown", email: "noah@example.com", role: "Student", date: "2024-05-19", avatar: "https://placehold.co/40x40.png?text=NB" },
    { name: "Emma Jones", email: "emma@example.com", role: "Admin", date: "2024-05-18", avatar: "https://placehold.co/40x40.png?text=EJ" },
    { name: "Ava Garcia", email: "ava@example.com", role: "Parent", date: "2024-05-17", avatar: "https://placehold.co/40x40.png?text=AG" },
];

const chartData = [
  { month: "January", users: 186 },
  { month: "February", users: 305 },
  { month: "March", users: 237 },
  { month: "April", users: 483 },
  { month: "May", users: 400 },
  { month: "June", users: 590 },
];

const chartConfig = {
  users: {
    label: "New Users",
    color: "hsl(var(--chart-1))",
  },
} satisfies ChartConfig;

export default function AdminDashboardPage() {
  return (
    <div className="grid gap-4 md:gap-8">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Students</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1,257</div>
            <p className="text-xs text-muted-foreground">+120 from last month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Parents</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">894</div>
            <p className="text-xs text-muted-foreground">+80 from last month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Courses</CardTitle>
            <BookOpen className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">25</div>
            <p className="text-xs text-muted-foreground">+2 new courses</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Now</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">+573</div>
            <p className="text-xs text-muted-foreground">Users online</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-5 lg:gap-8">
        <Card className="lg:col-span-3">
          <CardHeader>
            <CardTitle>User Engagement</CardTitle>
            <CardDescription>New user sign-ups over the last 6 months.</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartContainer config={chartConfig} className="h-[250px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="month" tickLine={false} axisLine={false} tickMargin={8} fontSize={12} />
                  <YAxis tickLine={false} axisLine={false} tickMargin={8} />
                  <ChartTooltip cursor={false} content={<ChartTooltipContent />} />
                  <defs>
                    <linearGradient id="fillUsers" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="var(--color-users)" stopOpacity={0.8} />
                      <stop offset="95%" stopColor="var(--color-users)" stopOpacity={0.1} />
                    </linearGradient>
                  </defs>
                  <Area type="monotone" dataKey="users" stroke="var(--color-users)" fillOpacity={1} fill="url(#fillUsers)" />
                </AreaChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
            <CardHeader>
                <CardTitle>Recent Sign-ups</CardTitle>
                <CardDescription>The latest users to join the platform.</CardDescription>
            </CardHeader>
            <CardContent>
                <div className="space-y-4">
                {recentSignups.slice(0, 4).map((user) => (
                    <div key={user.email} className="flex items-center gap-4">
                        <Avatar>
                            <AvatarImage src={user.avatar} />
                            <AvatarFallback>{user.name.substring(0,2)}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium truncate">{user.name}</p>
                            <p className="text-xs text-muted-foreground truncate">{user.email}</p>
                        </div>
                        <Badge variant={user.role === 'Admin' ? 'destructive' : 'secondary'} className="shrink-0">{user.role}</Badge>
                    </div>
                ))}
                </div>
            </CardContent>
        </Card>
      </div>
    </div>
  );
}
