
'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Edit, PlusCircle, Eye } from "lucide-react";
import Link from 'next/link';

export type Course = {
  id: string;
  title: string;
  description: string;
  ageGroup: string;
  tags: string[];
  objectives: string[];
  units: number;
  lessons: number;
  activities: number;
};

export default function AdminCoursesPage() {
  const [courses, setCourses] = useState<Course[]>([]);

  useEffect(() => {
    try {
      const savedCoursesStr = localStorage.getItem('adminCourses');
      const currentCourses: Course[] = savedCoursesStr ? JSON.parse(savedCoursesStr) : [];
      setCourses(currentCourses);
    } catch (error) {
        console.error("Failed to load courses from localStorage", error);
        setCourses([]);
    }
  }, []);

  return (
    <>
      <div className="grid gap-4 md:gap-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Manage Courses</CardTitle>
              <CardDescription>Edit course structures, add activities, or create a new course.</CardDescription>
            </div>
             <Button asChild>
              <Link href="/admin/courses/create">
                <PlusCircle className="mr-2 h-4 w-4" />
                Create New Course
              </Link>
            </Button>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Course Title</TableHead>
                  <TableHead>Units</TableHead>
                  <TableHead>Lessons</TableHead>
                  <TableHead>Activities</TableHead>
                  <TableHead><span className="sr-only">Actions</span></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {courses.map((course) => (
                  <TableRow key={course.id}>
                    <TableCell className="font-medium">{course.title}</TableCell>
                    <TableCell>{course.units}</TableCell>
                    <TableCell>{course.lessons}</TableCell>
                    <TableCell>{course.activities}</TableCell>
                    <TableCell className="text-right space-x-2">
                        <Button variant="outline" size="sm" asChild>
                            <Link href={`/courses/${course.id}`} target="_blank">
                                <Eye className="mr-2 h-4 w-4" /> Preview
                            </Link>
                        </Button>
                       <Button variant="outline" size="sm" asChild>
                          <Link href={`/admin/courses/${course.id}/edit`}>
                            <Edit className="mr-2 h-4 w-4" /> Edit
                          </Link>
                        </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
