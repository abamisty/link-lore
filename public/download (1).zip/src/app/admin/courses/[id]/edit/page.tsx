
'use client';

import { useState, useEffect, use } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, Route, ToyBrick, User, CircleDot, Upload, X, PlusCircle, Trash2, Gamepad2, ArrowLeft } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import type { Activity } from '@/app/admin/activities/page';
import Link from 'next/link';
import { type Course } from '@/app/admin/courses/page';
import { useRouter } from 'next/navigation';
import { type Character } from '@/app/admin/characters/page';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

const initialSteps = [
  { id: '01', name: 'Course Basics', icon: CircleDot, status: 'current' },
  { id: '02', name: 'Units', icon: ToyBrick, status: 'upcoming' },
  { id: '03', name: 'Lessons', icon: Route, status: 'upcoming' },
  { id: '04', name: 'Characters', icon: User, status: 'upcoming' },
  { id: '05', name: 'Review', icon: CheckCircle, status: 'upcoming' },
];

type Unit = {
    id: number;
    title: string;
    description: string;
};

type Lesson = {
    id: string;
    title: string;
    unitId: number | null;
    activityId?: string | null;
}

export default function EditCoursePage({ params }: { params: Promise<{ id: string }> }) {
    const { id: courseId } = use(params);
    const router = useRouter();
    const [currentStep, setCurrentStep] = useState(1);
    const [steps, setSteps] = useState(initialSteps);
    const { toast } = useToast();

    // Step 1 State
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [ageGroup, setAgeGroup] = useState('10-12');
    const [tags, setTags] = useState<string[]>([]);
    const [tagInput, setTagInput] = useState('');
    const [objectives, setObjectives] = useState<string[]>([]);
    const [objectiveInput, setObjectiveInput] = useState('');
    
    // Step 2 State
    const [units, setUnits] = useState<Unit[]>([]);
    const [newUnitTitle, setNewUnitTitle] = useState('');
    const [newUnitDescription, setNewUnitDescription] = useState('');
    
    // Step 3 State
    const [lessons, setLessons] = useState<Lesson[]>([]);
    const [newLessonTitle, setNewLessonTitle] = useState('');
    const [selectedUnitForLesson, setSelectedUnitForLesson] = useState<number | null>(null);
    const [selectedActivityForLesson, setSelectedActivityForLesson] = useState<string | null>(null);
    const [availableActivities, setAvailableActivities] = useState<Activity[]>([]);

    // Step 4 State
    const [availableCharacters, setAvailableCharacters] = useState<Character[]>([]);
    const [selectedCharacterIds, setSelectedCharacterIds] = useState<string[]>([]);

    useEffect(() => {
        const allCoursesStr = localStorage.getItem('adminCourses');
        const allCourses: Course[] = allCoursesStr ? JSON.parse(allCoursesStr) : [];
        const courseToEdit = allCourses.find(c => c.id === courseId);

        if (courseToEdit) {
            setTitle(courseToEdit.title);
            setDescription(courseToEdit.description);
            setAgeGroup(courseToEdit.ageGroup);
            setTags(courseToEdit.tags);
            setObjectives(courseToEdit.objectives);
        }

        const savedStructure = localStorage.getItem(`course-structure-${courseId}`);
        if (savedStructure) {
            const data = JSON.parse(savedStructure);
            setUnits(data.units || []);
            
            const allLessons = (data.units || []).flatMap((u: any) => (u.lessons || []).map((l:any) => ({...l, unitId: u.id}))) || [];
            setLessons(allLessons);
            setSelectedCharacterIds(data.selectedCharacterIds || []);
        }

        try {
            const savedActivities = localStorage.getItem('adminActivities');
            if (savedActivities) {
              const activities: Activity[] = JSON.parse(savedActivities);
              setAvailableActivities(activities.filter(a => a.status === 'Published'));
            }
        } catch (error) {
            console.error("Failed to parse activities from localStorage", error);
        }

         try {
            const savedCharacters = localStorage.getItem('characters');
            if (savedCharacters) {
                setAvailableCharacters(JSON.parse(savedCharacters));
            }
        } catch (error) {
            console.error("Failed to parse characters from localStorage", error);
        }
    }, [courseId]);

    const updateStepStatus = (stepIndex: number, status: 'current' | 'complete' | 'upcoming') => {
        setSteps(prevSteps => {
            const newSteps = [...prevSteps];
            if (newSteps[stepIndex]) {
               newSteps[stepIndex].status = status;
            }
            return newSteps;
        });
    };

    const handleNext = () => {
        if (currentStep < 5) {
             updateStepStatus(currentStep - 1, 'complete');
             updateStepStatus(currentStep, 'current');
             setCurrentStep(prev => prev + 1);
        }
    };

    const handlePrevious = () => {
        if (currentStep > 1) {
            updateStepStatus(currentStep - 1, 'upcoming');
            updateStepStatus(currentStep - 2, 'current');
            setCurrentStep(prev => prev - 1);
        }
    };

    const goToStep = (step: number) => {
        if (step > currentStep) {
            for (let i = currentStep - 1; i < step - 1; i++) {
                updateStepStatus(i, 'complete');
            }
        } else {
             for (let i = currentStep - 1; i > step - 1; i--) {
                updateStepStatus(i, 'upcoming');
            }
        }
        updateStepStatus(step - 1, 'current');
        setCurrentStep(step);
    }

    const handleTagKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
        if ((e.key === 'Enter' || e.key === ',') && tagInput.trim()) {
            e.preventDefault();
            if (tags.length < 10 && !tags.includes(tagInput.trim())) {
                setTags([...tags, tagInput.trim()]);
            }
            setTagInput('');
        }
    };
    
    const removeTag = (tagToRemove: string) => setTags(tags.filter(tag => tag !== tagToRemove));

    const handleObjectiveKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
        if (e.key === 'Enter' && objectiveInput.trim()) {
            e.preventDefault();
            if (objectives.length < 10) {
                setObjectives([...objectives, objectiveInput.trim()]);
            }
            setObjectiveInput('');
        }
    };

    const removeObjective = (objToRemove: string) => setObjectives(objectives.filter(obj => obj !== objToRemove));

    const handleAddUnit = () => {
        if (newUnitTitle.trim() && newUnitDescription.trim()) {
            const newUnit: Unit = {
                id: Date.now(),
                title: newUnitTitle.trim(),
                description: newUnitDescription.trim(),
            };
            setUnits([...units, newUnit]);
            setNewUnitTitle('');
            setNewUnitDescription('');
        }
    };
    
    const handleRemoveUnit = (unitId: number) => setUnits(units.filter(u => u.id !== unitId));

    const handleAddLesson = () => {
        if (newLessonTitle.trim() && selectedUnitForLesson) {
            const newLesson: Lesson = {
                id: String(Date.now()),
                title: newLessonTitle.trim(),
                unitId: selectedUnitForLesson,
                activityId: selectedActivityForLesson,
            };
            setLessons([...lessons, newLesson]);
            setNewLessonTitle('');
            setSelectedActivityForLesson(null);
        } else {
             toast({
                title: "Missing Information",
                description: "Please enter a lesson title and select a unit.",
                variant: "destructive"
            });
        }
    };

    const handleRemoveLesson = (lessonId: string) => {
        setLessons(lessons.filter(l => l.id !== lessonId));
    };
    
    const handleRemoveActivityFromLesson = (lessonId: string) => {
        setLessons(lessons.map(l => l.id === lessonId ? {...l, activityId: null } : l));
    }

    const handleToggleCharacter = (charId: string) => {
        setSelectedCharacterIds(prev => 
            prev.includes(charId) ? prev.filter(id => id !== charId) : [...prev, charId]
        );
    }
    
    const handleSaveChanges = () => {
        const courseStructure = {
            units: units.map(unit => ({
                ...unit,
                lessons: lessons.filter(l => l.unitId === unit.id).map(l => ({ id: l.id, title: l.title, activityId: l.activityId })),
            })),
            selectedCharacterIds,
        };

        const totalLessons = lessons.length;
        const totalActivities = lessons.filter(l => l.activityId).length;

        const updatedCourse: Course = {
            id: courseId,
            title,
            description,
            ageGroup,
            tags,
            objectives,
            units: units.length,
            lessons: totalLessons,
            activities: totalActivities,
        };
        
        const allCoursesStr = localStorage.getItem('adminCourses');
        const allCourses: Course[] = allCoursesStr ? JSON.parse(allCoursesStr) : [];
        const updatedCourses = allCourses.map(c => c.id === courseId ? updatedCourse : c);
        
        localStorage.setItem('adminCourses', JSON.stringify(updatedCourses));
        localStorage.setItem(`course-structure-${courseId}`, JSON.stringify(courseStructure));

        toast({
            title: "Course Updated",
            description: `"${title}" has been successfully saved.`
        });
        router.push('/admin/courses');
    }

    return (
        <div className="max-w-6xl mx-auto p-4 sm:p-6 lg:p-8">
            <div className="mb-8">
                <Link href="/admin/courses" className="inline-flex items-center text-sm font-medium text-muted-foreground hover:text-primary mb-4">
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Back to Courses
                </Link>
                <h1 className="text-3xl font-bold">Edit Course: {title}</h1>
                <p className="text-muted-foreground">Modify the course structure and content.</p>
            </div>

            <nav aria-label="Progress">
                <ol role="list" className="flex items-center">
                    {steps.map((step, stepIdx) => (
                        <li key={step.name} className={cn("relative", { 'flex-1': stepIdx !== steps.length - 1 })}>
                            <>
                                 {step.status === 'complete' ? (
                                     <button type="button" onClick={() => goToStep(stepIdx + 1)} className="flex items-center w-full text-left gap-x-4">
                                        <span className="flex h-10 w-10 items-center justify-center rounded-full bg-green-600">
                                            <CheckCircle className="h-6 w-6 text-white" />
                                        </span>
                                         <span className="flex flex-col">
                                            <span className="text-sm font-medium text-green-700">Step {step.id}</span>
                                            <span className="text-sm font-medium">{step.name}</span>
                                        </span>
                                    </button>
                                ) : step.status === 'current' ? (
                                    <div className="flex items-center gap-x-4" aria-current="step">
                                        <span className="flex h-10 w-10 items-center justify-center rounded-full bg-primary">
                                            <step.icon className="h-6 w-6 text-primary-foreground" aria-hidden="true" />
                                        </span>
                                        <span className="flex flex-col">
                                            <span className="text-sm font-medium text-primary">Step {step.id}</span>
                                            <span className="text-sm font-medium">{step.name}</span>
                                        </span>
                                    </div>
                                ) : (
                                    <div className="flex items-center gap-x-4">
                                        <span className="flex h-10 w-10 items-center justify-center rounded-full border-2 border-border bg-card">
                                            <step.icon className="h-6 w-6 text-muted-foreground" aria-hidden="true" />
                                        </span>
                                         <span className="flex flex-col">
                                            <span className="text-sm font-medium text-muted-foreground">Step {step.id}</span>
                                            <span className="text-sm font-medium text-muted-foreground">{step.name}</span>
                                        </span>
                                    </div>
                                )}
                                {stepIdx !== steps.length - 1 ? (
                                    <div className="absolute right-0 top-1/2 -z-10 h-0.5 w-full -translate-y-1/2 bg-border" aria-hidden="true" />
                                ) : null}
                            </>
                        </li>
                    ))}
                </ol>
            </nav>

            {currentStep === 1 && (
                 <Card className="mt-12">
                    <CardHeader>
                        <CardTitle>Course Information</CardTitle>
                    </CardHeader>
                    <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-8">
                        <div className="md:col-span-2 space-y-6">
                            <div className="space-y-2">
                                <Label htmlFor="title">Course Title *</Label>
                                <Input id="title" placeholder="Enter course title" value={title} onChange={(e) => setTitle(e.target.value)} required maxLength={100} />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="description">Description *</Label>
                                <Textarea id="description" placeholder="Describe what students will learn" value={description} onChange={(e) => setDescription(e.target.value)} required rows={5} maxLength={500} />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="age-group">Age Group *</Label>
                                <Select required value={ageGroup} onValueChange={setAgeGroup}>
                                    <SelectTrigger id="age-group">
                                        <SelectValue placeholder="Select age group" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="6-9">6-9 years</SelectItem>
                                        <SelectItem value="10-12">10-12 years</SelectItem>
                                        <SelectItem value="13-15">13-15 years</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="tags">Tags (max 10)</Label>
                                <Input id="tags" placeholder="Type tags separated by commas and press Enter" value={tagInput} onChange={(e) => setTagInput(e.target.value)} onKeyDown={handleTagKeyDown} />
                                <div className="flex flex-wrap gap-2 pt-2">
                                    {(tags || []).map(tag => (
                                        <Badge key={tag} variant="secondary">
                                            {tag}
                                            <button type="button" onClick={() => removeTag(tag)} className="ml-1 rounded-full p-0.5 hover:bg-destructive/20"><X className="h-3 w-3" /></button>
                                        </Badge>
                                    ))}
                                </div>
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="objectives">Learning Objectives * (max 10)</Label>
                                <Input id="objectives" placeholder="Enter objective and press Enter" value={objectiveInput} onChange={(e) => setObjectiveInput(e.target.value)} onKeyDown={handleObjectiveKeyDown} />
                                <div className="space-y-2 pt-2">
                                    {(objectives || []).map((obj, i) => (
                                        <div key={i} className="flex items-center gap-2 p-2 bg-secondary/50 rounded-md text-sm">
                                            <span className="flex-1">{obj}</span>
                                            <button type="button" onClick={() => removeObjective(obj)} className="rounded-full p-0.5 hover:bg-destructive/20"><X className="h-3 w-3" /></button>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="thumbnail">Course Thumbnail *</Label>
                            <div className="flex items-center justify-center w-full">
                                <label htmlFor="dropzone-file" className="flex flex-col items-center justify-center w-full h-64 border-2 border-border border-dashed rounded-lg cursor-pointer bg-card hover:bg-secondary/50">
                                    <div className="flex flex-col items-center justify-center pt-5 pb-6">
                                        <Upload className="w-8 h-8 mb-4 text-muted-foreground" />
                                        <p className="mb-2 text-sm text-muted-foreground"><span className="font-semibold">Upload a thumbnail</span></p>
                                        <p className="text-xs text-muted-foreground">PNG, JPG, GIF up to 2MB</p>
                                    </div>
                                    <Input id="dropzone-file" type="file" className="hidden" />
                                </label>
                            </div> 
                        </div>
                    </CardContent>
                </Card>
            )}

            {currentStep === 2 && (
                <Card className="mt-12">
                    <CardHeader>
                        <CardTitle>Course Units</CardTitle>
                        <CardDescription>Define the high-level sections of your course.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                        <Card className="bg-secondary/30 p-4">
                            <h3 className="font-semibold mb-2">Add New Unit</h3>
                            <div className="space-y-2">
                                <Label htmlFor="new-unit-title">Unit Title</Label>
                                <Input id="new-unit-title" placeholder="e.g., Understanding Decisions" value={newUnitTitle} onChange={(e) => setNewUnitTitle(e.target.value)} />
                                <Label htmlFor="new-unit-description">Unit Description</Label>
                                <Textarea id="new-unit-description" placeholder="A brief description of what this unit covers" value={newUnitDescription} onChange={(e) => setNewUnitDescription(e.target.value)} />
                                <Button onClick={handleAddUnit}><PlusCircle /> Add Unit</Button>
                            </div>
                        </Card>
                         <div className="space-y-4">
                            <h3 className="font-semibold">Existing Units</h3>
                            {units.length > 0 ? (
                                <div className="space-y-2">
                                {units.map((unit, index) => (
                                    <div key={unit.id} className="flex items-start justify-between p-3 border rounded-md">
                                        <div>
                                            <p className="font-medium">Unit {index + 1}: {unit.title}</p>
                                            <p className="text-sm text-muted-foreground">{unit.description}</p>
                                        </div>
                                        <Button variant="ghost" size="icon" onClick={() => handleRemoveUnit(unit.id)}>
                                            <Trash2 className="h-4 w-4 text-red-500" />
                                        </Button>
                                    </div>
                                ))}
                                </div>
                            ) : (
                                <p className="text-sm text-muted-foreground text-center py-4">No units created yet.</p>
                            )}
                        </div>
                    </CardContent>
                </Card>
            )}

            {currentStep === 3 && (
                 <Card className="mt-12">
                    <CardHeader>
                        <CardTitle>Course Lessons</CardTitle>
                        <CardDescription>Create lessons, assign them to units, and attach optional activities.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                        <Card className="bg-secondary/30 p-4">
                            <h3 className="font-semibold mb-2">Add New Lesson</h3>
                            <div className="space-y-4">
                                <div className="space-y-2">
                                    <Label htmlFor="new-lesson-title">Lesson Title</Label>
                                    <Input id="new-lesson-title" placeholder="e.g., What Are Decisions?" value={newLessonTitle} onChange={(e) => setNewLessonTitle(e.target.value)} />
                                </div>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div className="space-y-2">
                                        <Label htmlFor="lesson-unit">Assign to Unit *</Label>
                                        <Select onValueChange={(value) => setSelectedUnitForLesson(Number(value))}>
                                            <SelectTrigger id="lesson-unit">
                                                <SelectValue placeholder="Select a unit" />
                                            </SelectTrigger>
                                            <SelectContent>
                                                {units.map(unit => (
                                                    <SelectItem key={unit.id} value={String(unit.id)}>{unit.title}</SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                    </div>
                                    <div className="space-y-2">
                                        <Label htmlFor="lesson-activity">Attach Activity (Optional)</Label>
                                        <Select onValueChange={(value) => setSelectedActivityForLesson(value === 'null' ? null : value)} value={selectedActivityForLesson || 'null'}>
                                            <SelectTrigger id="lesson-activity">
                                                <SelectValue placeholder="Select an activity" />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="null">No Activity</SelectItem>
                                                {availableActivities.map(act => (
                                                    <SelectItem key={act.id} value={act.id}>{act.title} ({act.type})</SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                    </div>
                                </div>
                                <Button onClick={handleAddLesson}><PlusCircle /> Add Lesson</Button>
                            </div>
                        </Card>

                        <div className="space-y-4">
                             <h3 className="font-semibold">Course Structure</h3>
                              {units.map((unit) => (
                                <div key={unit.id} className="space-y-2">
                                    <h4 className="font-medium text-primary/80">Unit: {unit.title}</h4>
                                    <div className="pl-4 border-l-2 border-primary/20 space-y-2">
                                        {(lessons || []).filter(l => l.unitId === unit.id).map((lesson, index) => {
                                            const activity = availableActivities.find(a => a.id === lesson.activityId);
                                            return (
                                            <div key={lesson.id} className="flex items-center justify-between p-2 bg-secondary/50 rounded-md">
                                                <div className="flex-1">
                                                    <span>Lesson {index + 1}: {lesson.title}</span>
                                                    {activity && (
                                                        <div className="flex items-center gap-2 text-xs text-muted-foreground mt-1">
                                                            <Gamepad2 className="h-3 w-3" />
                                                            <span>{activity.title}</span>
                                                            <button type="button" onClick={() => handleRemoveActivityFromLesson(lesson.id)} className="ml-1 rounded-full p-0.5 hover:bg-destructive/20"><X className="h-3 w-3" /></button>
                                                        </div>
                                                    )}
                                                </div>
                                                <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => handleRemoveLesson(lesson.id)}>
                                                    <Trash2 className="h-4 w-4 text-red-500" />
                                                </Button>
                                            </div>
                                            )
                                        })}
                                         {(lessons || []).filter(l => l.unitId === unit.id).length === 0 && (
                                            <p className="text-xs text-muted-foreground p-2">No lessons in this unit yet.</p>
                                        )}
                                    </div>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                 </Card>
            )}

            {currentStep === 4 && (
                 <Card className="mt-12">
                    <CardHeader>
                        <CardTitle>Assign Characters</CardTitle>
                        <CardDescription>Select the characters that will appear in this course.</CardDescription>
                    </CardHeader>
                    <CardContent className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                        {availableCharacters.map(char => (
                            <Card 
                                key={char.id}
                                onClick={() => handleToggleCharacter(char.id)}
                                className={cn(
                                    "cursor-pointer transition-all",
                                    selectedCharacterIds.includes(char.id) ? 'border-primary ring-2 ring-primary' : 'border-border'
                                )}
                            >
                                <CardContent className="p-4 flex flex-col items-center text-center">
                                    <Avatar className="w-20 h-20 mb-3">
                                        <AvatarImage src={char.avatar} />
                                        <AvatarFallback>{char.name.charAt(0)}</AvatarFallback>
                                    </Avatar>
                                    <p className="font-semibold">{char.name}</p>
                                    <p className="text-xs text-muted-foreground">{char.type} - {char.age}</p>
                                </CardContent>
                            </Card>
                        ))}
                    </CardContent>
                </Card>
            )}

            {currentStep === 5 && (
                <Card className="mt-12">
                    <CardHeader>
                        <CardTitle>Review & Update</CardTitle>
                        <CardDescription>Review the course details below before saving your changes.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-8">
                        <section>
                             <div className="flex justify-between items-center mb-4">
                                <h3 className="text-xl font-semibold">Course Basics</h3>
                                <Button variant="outline" size="sm" onClick={() => goToStep(1)}>Edit</Button>
                            </div>
                            <div className="space-y-2 text-sm">
                                <p><strong>Title:</strong> {title}</p>
                                <p><strong>Description:</strong> {description}</p>
                                <p><strong>Age Group:</strong> {ageGroup}</p>
                                <p><strong>Tags:</strong> {(tags || []).join(', ')}</p>
                                <p><strong>Objectives:</strong></p>
                                <ul className="list-disc pl-5">
                                    {(objectives || []).map((obj, i) => <li key={i}>{obj}</li>)}
                                </ul>
                            </div>
                        </section>
                        <hr/>
                        <section>
                            <div className="flex justify-between items-center mb-4">
                                <h3 className="text-xl font-semibold">Course Structure</h3>
                                <div>
                                    <Button variant="outline" size="sm" onClick={() => goToStep(2)} className="mr-2">Edit Units</Button>
                                    <Button variant="outline" size="sm" onClick={() => goToStep(3)}>Edit Lessons</Button>
                                </div>
                            </div>
                             <div className="space-y-4">
                                {units.map((unit) => (
                                    <div key={unit.id}>
                                        <h4 className="font-medium">Unit: {unit.title}</h4>
                                        <ul className="list-disc pl-8 text-sm text-muted-foreground">
                                            {(lessons || []).filter(l => l.unitId === unit.id).map(lesson => <li key={lesson.id}>{lesson.title}</li>)}
                                        </ul>
                                    </div>
                                ))}
                            </div>
                        </section>
                        <hr/>
                        <section>
                             <div className="flex justify-between items-center mb-4">
                                <h3 className="text-xl font-semibold">Characters</h3>
                                <Button variant="outline" size="sm" onClick={() => goToStep(4)}>Edit</Button>
                            </div>
                            <div className="flex flex-wrap gap-4">
                                {selectedCharacterIds.map(id => {
                                    const char = availableCharacters.find(c => c.id === id);
                                    if (!char) return null;
                                    return (
                                        <div key={id} className="flex items-center gap-2 p-2 border rounded-md bg-secondary">
                                            <Avatar className="h-8 w-8">
                                                <AvatarImage src={char.avatar} />
                                                <AvatarFallback>{char.name.charAt(0)}</AvatarFallback>
                                            </Avatar>
                                            <span className="text-sm font-medium">{char.name}</span>
                                        </div>
                                    )
                                })}
                            </div>
                        </section>
                    </CardContent>
                    <CardFooter>
                         <Button size="lg" onClick={handleSaveChanges} className="w-full">Update Course</Button>
                    </CardFooter>
                </Card>
            )}


            <CardFooter className="justify-end gap-2 mt-8 p-0">
                <div>
                     <Button variant="outline" onClick={handlePrevious} disabled={currentStep === 1}>Previous</Button>
                </div>
                <div className="flex gap-2">
                    <Button onClick={handleNext} disabled={currentStep === 5}>Next</Button>
                </div>
            </CardFooter>
        </div>
    );
}
