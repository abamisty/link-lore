
'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Edit, Trash2, User, Smile, PlusCircle } from 'lucide-react';
import { AddEditCharacterDialog } from '@/components/admin/add-edit-character-dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from '@/hooks/use-toast';

export type Character = {
  id: string;
  name: string;
  description: string;
  type: 'Human' | 'Animal' | 'Robot' | 'Other';
  age: 'child' | 'teen' | 'adult' | 'senior';
  avatar: string;
  personalityTraits: string[];
  voiceSettings: {
    pitch: number;
    speed: number;
    tone: string;
  };
  visualCustomization: {
    colorScheme: string;
    outfit: string;
    accessories: string[];
  };
};

const initialCharacters: Character[] = [
  {
    id: 'char_1',
    name: 'Peter',
    description: 'A curious and energetic programmer who loves solving puzzles.',
    type: 'Human',
    age: 'adult',
    avatar: 'https://placehold.co/100x100.png?text=P',
    personalityTraits: ['Energetic', 'Humorous', 'Creative'],
    voiceSettings: { pitch: 50, speed: 50, tone: 'Friendly' },
    visualCustomization: { colorScheme: 'blue', outfit: 'casual', accessories: ['glasses'] },
  },
  {
    id: 'char_2',
    name: 'Robert',
    description: 'A wise and calm mentor, always ready with a helpful story.',
    type: 'Human',
    age: 'senior',
    avatar: 'https://placehold.co/100x100.png?text=R',
    personalityTraits: ['Wise', 'Calm'],
    voiceSettings: { pitch: 40, speed: 45, tone: 'Calm' },
    visualCustomization: { colorScheme: 'green', outfit: 'formal', accessories: [] },
  },
];

export default function CharacterManagementPage() {
  const [characters, setCharacters] = useState<Character[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [selectedCharacter, setSelectedCharacter] = useState<Character | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    try {
      const savedCharacters = localStorage.getItem('characters');
      if (savedCharacters) {
        setCharacters(JSON.parse(savedCharacters));
      } else {
        setCharacters(initialCharacters);
      }
    } catch (error) {
      console.error("Failed to parse characters from localStorage", error);
      setCharacters(initialCharacters);
    }
  }, []);

  useEffect(() => {
    if (characters.length > 0) {
      localStorage.setItem('characters', JSON.stringify(characters));
    }
  }, [characters]);

  const handleAddClick = () => {
    setSelectedCharacter(null);
    setIsDialogOpen(true);
  };

  const handleEditClick = (character: Character) => {
    setSelectedCharacter(character);
    setIsDialogOpen(true);
  };
  
  const handleDeleteClick = (character: Character) => {
    setSelectedCharacter(character);
    setIsDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = () => {
    if (selectedCharacter) {
      setCharacters(prev => prev.filter(c => c.id !== selectedCharacter.id));
      toast({
        title: 'Character Deleted',
        description: `"${selectedCharacter.name}" has been removed.`,
        variant: 'destructive',
      });
      setIsDeleteDialogOpen(false);
      setSelectedCharacter(null);
    }
  };

  const handleSaveCharacter = (characterData: Omit<Character, 'id'>) => {
    if (selectedCharacter) {
      // Update existing character
      const updatedCharacter = { ...characterData, id: selectedCharacter.id };
      setCharacters(characters.map(c => c.id === selectedCharacter.id ? updatedCharacter : c));
      toast({ title: 'Character Updated!', description: `"${characterData.name}" has been saved.`});
    } else {
      // Add new character
      const newCharacter = { ...characterData, id: `char_${Date.now()}` };
      setCharacters([newCharacter, ...characters]);
       toast({ title: 'Character Added!', description: `"${characterData.name}" has been created.`});
    }
  };

  return (
    <>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Character Management</h1>
          <p className="text-muted-foreground">Create and manage course characters</p>
        </div>

        <Card>
          <CardHeader className="flex flex-col md:flex-row items-center gap-4">
            <div className="flex-1 w-full">
              <Input placeholder="Search characters..." />
            </div>
            <div className="flex gap-2 w-full md:w-auto">
              <Select>
                <SelectTrigger className="w-full md:w-[180px]">
                  <SelectValue placeholder="All Types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="human">Human</SelectItem>
                  <SelectItem value="animal">Animal</SelectItem>
                  <SelectItem value="robot">Robot</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
              <Select>
                <SelectTrigger className="w-full md:w-[180px]">
                  <SelectValue placeholder="All Ages" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="child">Child</SelectItem>
                  <SelectItem value="teen">Teen</SelectItem>
                  <SelectItem value="adult">Adult</SelectItem>
                  <SelectItem value="senior">Senior</SelectItem>
                </SelectContent>
              </Select>
            </div>
             <Button onClick={handleAddClick} className="w-full md:w-auto">
              <PlusCircle className="mr-2" /> Add Character
            </Button>
          </CardHeader>
        </Card>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {characters.map(character => (
            <Card key={character.id} className="flex flex-col">
              <CardHeader className="items-center">
                <Avatar className="w-24 h-24 mb-4">
                  <AvatarImage src={character.avatar} />
                  <AvatarFallback>{character.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <CardTitle>{character.name}</CardTitle>
                <div className="flex gap-2 mt-2">
                  <Badge variant="outline"><User className="mr-1 h-3 w-3"/>{character.type}</Badge>
                  <Badge variant="outline"><Smile className="mr-1 h-3 w-3"/>{character.age}</Badge>
                </div>
              </CardHeader>
              <CardContent className="flex-grow text-center space-y-4">
                <p className="text-sm text-muted-foreground">{character.description}</p>
                <div className="flex flex-wrap gap-2 justify-center">
                  {(character.personalityTraits || []).map(trait => (
                    <Badge key={trait} variant="secondary">{trait}</Badge>
                  ))}
                </div>
              </CardContent>
              <CardFooter className="flex gap-2">
                <Button variant="outline" className="w-full" onClick={() => handleEditClick(character)}>
                  <Edit className="mr-2 h-4 w-4" /> Edit
                </Button>
                <Button variant="destructive" className="w-full" onClick={() => handleDeleteClick(character)}>
                  <Trash2 className="mr-2 h-4 w-4" /> Delete
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>

      <AddEditCharacterDialog
        open={isDialogOpen}
        onOpenChange={setIsDialogOpen}
        character={selectedCharacter}
        onSave={handleSaveCharacter}
      />
      
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the character "{selectedCharacter?.name}".
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteConfirm}>Continue</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
