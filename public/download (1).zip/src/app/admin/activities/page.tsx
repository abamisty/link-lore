
'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from "@/components/ui/dropdown-menu";
import { MoreHorizontal, Edit, Trash2, Eye } from "lucide-react";
import { CreateActivityDialog } from '@/components/admin/create-activity-dialog';
import { EditActivityDialog } from '@/components/admin/edit-activity-dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from '@/hooks/use-toast';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

const initialActivities: Activity[] = [
  {
    id: 'act_1001',
    title: 'Playground Dilemma',
    type: 'Scenario',
    dateCreated: '2024-07-31',
    status: 'Published',
    instructions: 'Read the scenario and answer the questions that follow.',
    content: {}
  },
  {
    id: 'act_1002',
    title: 'Company Values',
    type: 'Accordion',
    dateCreated: '2024-07-30',
    status: 'Published',
    instructions: 'Click on each value to learn more.',
    content: {}
  },
  {
    id: 'act_1003',
    title: 'The Honest Camper',
    type: 'Drag the Words',
    dateCreated: '2024-07-29',
    status: 'Published',
    instructions: 'Drag the words to complete the story about honesty.',
    content: {}
  },
  {
    id: 'act_1004',
    title: 'What is Honesty?',
    type: 'Multiple Choice',
    dateCreated: '2024-07-28',
    status: 'Published',
    instructions: 'Select the best definition of honesty.',
    content: {}
  },
  {
    id: 'act_1005',
    title: 'Pledge of Kindness',
    type: 'Fill in the Blanks',
    dateCreated: '2024-07-27',
    status: 'Draft',
    instructions: 'Fill in the missing words to complete the pledge.',
    content: {}
  },
  {
    id: 'act_1006',
    title: 'Prioritizing Values',
    type: 'Values Sorting',
    dateCreated: '2024-07-26',
    status: 'Draft',
    instructions: 'Sort these values into the correct categories.',
    content: {}
  },
  {
    id: 'act_1007',
    title: 'Decision Making Quiz',
    type: 'Question Set',
    dateCreated: '2024-07-25',
    status: 'Draft',
    instructions: 'Answer the following questions to test your knowledge.',
    content: {}
  },
  {
    id: 'act_1008',
    title: 'A Talk About Sharing',
    type: 'Interactive Dialogue',
    dateCreated: '2024-07-24',
    status: 'Draft',
    instructions: 'Read the dialogue between the characters.',
    content: {}
  }
];

export type Activity = {
  id: string;
  title: string;
  type: string;
  dateCreated: string;
  status: 'Published' | 'Draft';
  instructions?: string;
  content?: any; 
};

export default function AdminActivitiesPage() {
  const [activities, setActivities] = useState<Activity[]>([]);
  const [selectedActivity, setSelectedActivity] = useState<Activity | null>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const { toast } = useToast();
  const router = useRouter();

  useEffect(() => {
    try {
        const savedActivities = localStorage.getItem('adminActivities');
        if (savedActivities) {
          setActivities(JSON.parse(savedActivities));
        } else {
          setActivities(initialActivities);
          localStorage.setItem('adminActivities', JSON.stringify(initialActivities));
        }
    } catch (error) {
        console.error("Failed to parse activities from localStorage", error);
        setActivities(initialActivities);
    }
  }, []);

  useEffect(() => {
    // We only want to save if it's not the initial empty state from a fresh load
    if (activities.length > 0) {
      localStorage.setItem('adminActivities', JSON.stringify(activities));
    }
  }, [activities]);

  const handleActivityCreated = (newActivity: Omit<Activity, 'id' | 'dateCreated' | 'status'> & { status: 'Draft' | 'Published'}) => {
    const activityToAdd: Activity = {
      ...newActivity,
      id: `act_${String(Date.now()).slice(-4)}`,
      dateCreated: new Date().toISOString().split('T')[0],
      type: newActivity.type,
    };
    setActivities(prev => [activityToAdd, ...prev]);
  };
  
  const handleEditClick = (activity: Activity) => {
    const editUrlMap: Record<string, string> = {
      'Fill in the Blanks': `/admin/activities/fill-in-the-blanks/${activity.id}/edit`,
      'Values Sorting': `/admin/activities/values-sorting/${activity.id}/edit`,
      'Multiple Choice': `/admin/activities/multiple-choice/${activity.id}/edit`,
      'Accordion': `/admin/activities/accordion/${activity.id}/edit`,
      'Drag the Words': `/admin/activities/drag-the-words/${activity.id}/edit`,
      'Scenario': `/admin/activities/scenario/${activity.id}/edit`,
      'Question Set': `/admin/activities/question-set/${activity.id}/edit`,
      'Interactive Dialogue': `/admin/activities/interactive-dialogue/${activity.id}/edit`,
      'Branching Scenario': `/admin/activities/branching-scenario/${activity.id}/edit`,
    };

    const url = editUrlMap[activity.type];
    if (url) {
      router.push(url);
    } else {
        setSelectedActivity(activity);
        setIsEditDialogOpen(true);
    }
  };

  const getPreviewUrl = (activity: Activity) => {
    // This creates a dummy course context to display the activity
    const courseId = 'preview-course';
    const lessonId = `preview-lesson-${activity.id}`;
    
    // We can use localStorage to pass the activity to the preview page
    // This avoids complex URL state and mimics a real-world scenario
    // where a lesson page would fetch its content.
    if (typeof window !== 'undefined') {
        const previewCourse = {
            id: courseId,
            title: "Activity Preview Mode",
            units: [{
                id: 1,
                title: "Preview Unit",
                lessons: [{
                    id: lessonId,
                    title: activity.title,
                    activityId: activity.id
                }]
            }]
        };
        localStorage.setItem(`course-structure-${courseId}`, JSON.stringify(previewCourse));
    }
    
    return `/courses/${courseId}/${lessonId}`;
  }

  const handleActivityUpdated = (updatedActivity: Activity) => {
    setActivities(prev => prev.map(act => act.id === updatedActivity.id ? updatedActivity : act));
    toast({
        title: 'Activity Updated!',
        description: `"${updatedActivity.title}" has been successfully updated.`,
    });
  };

  const handleDeleteClick = (activity: Activity) => {
    setSelectedActivity(activity);
    setIsDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = () => {
    if (selectedActivity) {
        setActivities(prev => prev.filter(act => act.id !== selectedActivity.id));
        toast({
            title: 'Activity Deleted!',
            description: `"${selectedActivity.title}" has been removed.`,
            variant: 'destructive'
        });
        setIsDeleteDialogOpen(false);
        setSelectedActivity(null);
    }
  };
  
  return (
    <>
      <div className="grid gap-4 md:gap-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Interactive Activities</CardTitle>
              <CardDescription>Create and manage built-in activities for your courses.</CardDescription>
            </div>
            <CreateActivityDialog onActivityCreated={handleActivityCreated} />
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Title</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Date Created</TableHead>
                  <TableHead><span className="sr-only">Actions</span></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {activities.map((activity) => (
                  <TableRow key={activity.id}>
                    <TableCell className="font-medium">{activity.title}</TableCell>
                    <TableCell>
                      <Badge variant={'default'}>
                        {activity.type}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant={activity.status === 'Published' ? 'default' : 'secondary'}>
                        {activity.status}
                      </Badge>
                    </TableCell>
                    <TableCell>{activity.dateCreated}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" className="h-8 w-8 p-0">
                            <span className="sr-only">Open menu</span>
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                            <DropdownMenuItem asChild>
                                <Link href={getPreviewUrl(activity)} target="_blank">
                                    <Eye className="mr-2 h-4 w-4" /> Preview
                                </Link>
                            </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleEditClick(activity)}>
                            <Edit className="mr-2 h-4 w-4" /> Edit
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => handleDeleteClick(activity)} className="text-red-600">
                            <Trash2 className="mr-2 h-4 w-4" /> Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
                 {activities.length === 0 && (
                    <TableRow>
                        <TableCell colSpan={5} className="text-center h-24">
                            No activities created yet.
                        </TableCell>
                    </TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      {selectedActivity && (
        <EditActivityDialog
          open={isEditDialogOpen}
          onOpenChange={setIsEditDialogOpen}
          activity={selectedActivity}
          onActivityUpdated={handleActivityUpdated}
        />
      )}

      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the activity
              "{selectedActivity?.title}".
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteConfirm}>Continue</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

    