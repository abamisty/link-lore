
'use client';

import { useState, useEffect, use } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft, Save, Sparkles } from 'lucide-react';
import Link from 'next/link';
import type { Activity } from '@/app/admin/activities/page';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';

type Word = {
    text: string;
    isBlank: boolean;
};

export default function DragTheWordsEditPage({ params }: { params: Promise<{ id: string }> }) {
    const { id: activityId } = use(params);
    const [activity, setActivity] = useState<Activity | null>(null);
    const [paragraph, setParagraph] = useState('');
    const [words, setWords] = useState<Word[]>([]);
    const { toast } = useToast();

    useEffect(() => {
        const savedActivities = localStorage.getItem('adminActivities');
        if (savedActivities) {
            const activities: Activity[] = JSON.parse(savedActivities);
            const currentActivity = activities.find(a => a.id === activityId);
            if (currentActivity) {
                setActivity(currentActivity);
                setParagraph(currentActivity.content?.paragraph || '');
                setWords(currentActivity.content?.words || []);
            }
        }
    }, [activityId]);

    const generateWordsFromParagraph = () => {
        const newWords = paragraph.split(/(\s+)/).filter(Boolean).map(text => ({
            text,
            isBlank: false
        }));
        setWords(newWords);
        toast({
            title: "Words Generated!",
            description: "Click on words below to turn them into draggable blanks."
        });
    }

    const toggleBlank = (index: number) => {
        // Prevent making whitespace a blank
        if (words[index].text.trim() === '') return;

        const newWords = [...words];
        newWords[index].isBlank = !newWords[index].isBlank;
        setWords(newWords);
    };

    const handleSave = () => {
        if (!activity) return;

        const updatedActivity = {
            ...activity,
            content: {
                paragraph,
                words,
            },
        };

        const savedActivities = localStorage.getItem('adminActivities');
        if (savedActivities) {
            let activities: Activity[] = JSON.parse(savedActivities);
            activities = activities.map(a => a.id === activityId ? updatedActivity : a);
            localStorage.setItem('adminActivities', JSON.stringify(activities));
            setActivity(updatedActivity);
            toast({
                title: 'Activity Saved!',
                description: `"${activity.title}" has been successfully saved.`,
            });
        }
    };
    
    const handleActivityDetailsChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        if (!activity) return;
        const { name, value } = e.target;
        setActivity({ ...activity, [name]: value });
    }

    const handleStatusChange = (checked: boolean) => {
        if (!activity) return;
        const newStatus = checked ? 'Published' : 'Draft';
        setActivity(prev => prev ? { ...prev, status: newStatus } : null);
    };
    
    if (!activity) {
        return <div>Loading activity...</div>;
    }

    const blankWords = words.filter(w => w.isBlank).map(w => w.text);

    return (
        <div className="grid gap-4 md:gap-8">
            <div className="flex items-center gap-4">
                 <Button asChild variant="outline" size="icon">
                    <Link href="/admin/activities">
                        <ArrowLeft className="h-4 w-4" />
                    </Link>
                </Button>
                <h1 className="text-2xl font-bold">Edit: {activity.title}</h1>
            </div>
            
            <Card>
                <CardHeader>
                    <CardTitle>Activity Details</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="space-y-2">
                        <Label htmlFor="title">Activity Title</Label>
                        <Input id="title" name="title" value={activity.title} onChange={handleActivityDetailsChange} />
                    </div>
                     <div className="space-y-2">
                        <Label htmlFor="instructions">Instructions</Label>
                        <Textarea id="instructions" name="instructions" value={activity.instructions} onChange={handleActivityDetailsChange} placeholder="Enter instructions for the student." />
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Content Creator</CardTitle>
                    <CardDescription>Create the "Drag the Words" activity content.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="space-y-2">
                        <Label htmlFor="paragraph">1. Write your paragraph</Label>
                        <Textarea
                            id="paragraph"
                            value={paragraph}
                            onChange={(e) => setParagraph(e.target.value)}
                            placeholder="Type or paste your full paragraph here."
                            rows={5}
                        />
                    </div>
                     <Button onClick={generateWordsFromParagraph} disabled={!paragraph}>
                        <Sparkles className="mr-2 h-4 w-4" />
                        Generate Words
                    </Button>
                    {words.length > 0 && (
                        <div className="space-y-2">
                            <Label>2. Click words to make them blanks</Label>
                            <div className="p-4 border rounded-md flex flex-wrap gap-x-1">
                                {words.map((word, index) => (
                                    <button
                                        key={index}
                                        onClick={() => toggleBlank(index)}
                                        className={`px-1 rounded-md transition-colors ${
                                            word.isBlank
                                                ? 'bg-primary text-primary-foreground'
                                                : word.text.trim() === '' ? '' : 'hover:bg-secondary/80'
                                        }`}
                                    >
                                        {word.text.trim() === '' ? <span dangerouslySetInnerHTML={{__html: '&nbsp;'}} /> : word.text}
                                    </button>
                                ))}
                            </div>
                        </div>
                    )}
                     {blankWords.length > 0 && (
                        <div className="space-y-2">
                            <Label>3. Draggable Word Bank (Preview)</Label>
                            <div className="p-4 border rounded-md flex flex-wrap gap-2 bg-secondary/50">
                                {blankWords.map((word, index) => (
                                    <div key={index} className="px-3 py-1.5 rounded-md bg-card shadow-sm cursor-grab">
                                        {word}
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                </CardContent>
            </Card>

             <Card>
                <CardHeader>
                    <CardTitle>Settings</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="flex items-center justify-between rounded-lg border p-4">
                         <div className="space-y-0.5">
                            <Label>Status</Label>
                            <p className="text-sm text-muted-foreground">
                                Make this activity available to students.
                            </p>
                         </div>
                         <Switch
                            checked={activity.status === 'Published'}
                            onCheckedChange={handleStatusChange}
                        />
                    </div>
                </CardContent>
                <CardFooter>
                    <Button onClick={handleSave} className="ml-auto">
                        <Save className="mr-2 h-4 w-4" /> Save Activity
                    </Button>
                </CardFooter>
            </Card>
        </div>
    );
}
