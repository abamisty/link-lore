
'use client';

import { useState, useEffect, use } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft, Save, PlusCircle, Trash2, GitBranch, ChevronsRight, Flag, Star } from 'lucide-react';
import Link from 'next/link';
import type { Activity } from '@/app/admin/activities/page';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import Image from 'next/image';

type Choice = {
    id: string;
    text: string;
    nextSceneId: string | null;
};

type Scene = {
    id: string;
    title: string;
    text: string;
    image: string | null;
    isEnding: boolean;
    choices: Choice[];
};

export default function BranchingScenarioEditPage({ params }: { params: Promise<{ id: string }> }) {
    const { id: activityId } = use(params);
    const [activity, setActivity] = useState<Activity | null>(null);
    const [scenes, setScenes] = useState<Scene[]>([]);
    const [startSceneId, setStartSceneId] = useState<string | null>(null);
    const { toast } = useToast();

    useEffect(() => {
        const savedActivities = localStorage.getItem('adminActivities');
        if (savedActivities) {
            const activities: Activity[] = JSON.parse(savedActivities);
            const currentActivity = activities.find(a => a.id === activityId);
            if (currentActivity) {
                setActivity(currentActivity);
                setScenes(currentActivity.content?.scenes || []);
                setStartSceneId(currentActivity.content?.startSceneId || null);
            }
        }
    }, [activityId]);
    
    // SCENE MANAGEMENT
    const handleAddScene = () => {
        const newSceneId = String(Date.now());
        const newScene: Scene = {
            id: newSceneId,
            title: `New Scene ${scenes.length + 1}`,
            text: '',
            image: null,
            isEnding: false,
            choices: []
        };
        setScenes([...scenes, newScene]);
        if (!startSceneId) {
            setStartSceneId(newSceneId);
        }
    };
    const handleRemoveScene = (sceneId: string) => {
        setScenes(scenes.filter(s => s.id !== sceneId));
        // Also remove any choices pointing to this scene
        setScenes(prevScenes => prevScenes.map(s => ({
            ...s,
            choices: s.choices.map(c => c.nextSceneId === sceneId ? { ...c, nextSceneId: null } : c)
        })));
        if (startSceneId === sceneId) {
            setStartSceneId(scenes.length > 1 ? scenes.filter(s => s.id !== sceneId)[0].id : null);
        }
    };
     const handleSceneChange = (sceneId: string, field: keyof Omit<Scene, 'id'|'choices'>, value: string | boolean | null) => {
        setScenes(scenes.map(s => s.id === sceneId ? { ...s, [field]: value } : s));
    };
    const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>, sceneId: string) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                handleSceneChange(sceneId, 'image', reader.result as string);
            };
            reader.readAsDataURL(file);
        }
    };

    // CHOICE MANAGEMENT
    const handleAddChoice = (sceneId: string) => {
        const newChoice: Choice = { id: String(Date.now()), text: '', nextSceneId: null };
        setScenes(scenes.map(s => s.id === sceneId ? { ...s, choices: [...s.choices, newChoice] } : s));
    };
    const handleRemoveChoice = (sceneId: string, choiceId: string) => {
        setScenes(scenes.map(s => s.id === sceneId ? { ...s, choices: s.choices.filter(c => c.id !== choiceId) } : s));
    };
    const handleChoiceChange = (sceneId: string, choiceId: string, field: keyof Omit<Choice, 'id'>, value: string | null) => {
        setScenes(scenes.map(s => s.id === sceneId 
            ? { ...s, choices: s.choices.map(c => c.id === choiceId ? { ...c, [field]: value } : c) }
            : s
        ));
    };

    const handleSave = () => {
        if (!activity) return;
        const updatedActivity = {
            ...activity,
            content: { scenes, startSceneId },
        };
        const savedActivities = localStorage.getItem('adminActivities');
        if (savedActivities) {
            let activities: Activity[] = JSON.parse(savedActivities);
            activities = activities.map(a => a.id === activityId ? updatedActivity : a);
            localStorage.setItem('adminActivities', JSON.stringify(activities));
            setActivity(updatedActivity);
            toast({
                title: 'Activity Saved!',
                description: `"${activity.title}" has been successfully saved.`,
            });
        }
    };
    
    const handleActivityDetailsChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        if (!activity) return;
        setActivity({ ...activity, [e.target.name]: e.target.value });
    };

    const handleStatusChange = (checked: boolean) => {
        if (!activity) return;
        setActivity(prev => prev ? { ...prev, status: checked ? 'Published' : 'Draft' } : null);
    };

    if (!activity) {
        return <div>Loading activity...</div>;
    }
    
    return (
         <div className="grid gap-4 md:gap-8">
            <div className="flex items-center gap-4">
                 <Button asChild variant="outline" size="icon">
                    <Link href="/admin/activities">
                        <ArrowLeft className="h-4 w-4" />
                    </Link>
                </Button>
                <h1 className="text-2xl font-bold">Edit: {activity.title}</h1>
            </div>
            
            <Card>
                <CardHeader>
                    <CardTitle>Activity Details</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="space-y-2">
                        <Label htmlFor="title">Activity Title</Label>
                        <Input id="title" name="title" value={activity.title} onChange={handleActivityDetailsChange} />
                    </div>
                     <div className="space-y-2">
                        <Label htmlFor="instructions">Instructions</Label>
                        <Textarea id="instructions" name="instructions" value={activity.instructions} onChange={handleActivityDetailsChange} placeholder="Enter instructions for the student." />
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Scenario Builder</CardTitle>
                    <CardDescription>Create the scenes and choices for your branching scenario.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="space-y-2">
                        <Label htmlFor="startScene">Start Scene</Label>
                        <Select value={startSceneId || ''} onValueChange={setStartSceneId}>
                            <SelectTrigger id="startScene">
                                <SelectValue placeholder="Select the starting scene" />
                            </SelectTrigger>
                            <SelectContent>
                                {scenes.map(s => <SelectItem key={s.id} value={s.id}>{s.title}</SelectItem>)}
                            </SelectContent>
                        </Select>
                    </div>

                    {scenes.map(scene => (
                        <Card key={scene.id} className="p-4 relative bg-secondary/30">
                            <div className="absolute top-2 right-2 flex gap-2">
                                {scene.id === startSceneId && <Badge variant="default"><Star className="h-3 w-3 mr-1"/>Start</Badge>}
                                {scene.isEnding && <Badge variant="destructive"><Flag className="h-3 w-3 mr-1"/>End</Badge>}
                                <Button variant="ghost" size="icon" onClick={() => handleRemoveScene(scene.id)}>
                                    <Trash2 className="h-4 w-4 text-red-500" />
                                </Button>
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                {/* Scene Details */}
                                <div className="space-y-4">
                                    <div className="space-y-1">
                                        <Label htmlFor={`scene-title-${scene.id}`}>Scene Title</Label>
                                        <Input id={`scene-title-${scene.id}`} value={scene.title} onChange={(e) => handleSceneChange(scene.id, 'title', e.target.value)} />
                                    </div>
                                    <div className="space-y-1">
                                        <Label htmlFor={`scene-text-${scene.id}`}>Scene Text</Label>
                                        <Textarea id={`scene-text-${scene.id}`} value={scene.text} onChange={(e) => handleSceneChange(scene.id, 'text', e.target.value)} rows={5}/>
                                    </div>
                                    <div className="space-y-2">
                                        <Label>Scene Image</Label>
                                        {scene.image && <Image src={scene.image} alt="Scene image" width={200} height={112} className="rounded-md object-cover" />}
                                        <Input type="file" onChange={(e) => handleImageUpload(e, scene.id)} accept="image/*" />
                                    </div>
                                     <div className="flex items-center space-x-2">
                                        <Switch id={`is-ending-${scene.id}`} checked={scene.isEnding} onCheckedChange={(checked) => handleSceneChange(scene.id, 'isEnding', checked)} />
                                        <Label htmlFor={`is-ending-${scene.id}`}>This is an ending scene</Label>
                                    </div>
                                </div>
                                {/* Choices */}
                                <div className="space-y-4">
                                    <Label>Choices</Label>
                                    {scene.choices.map(choice => (
                                        <div key={choice.id} className="p-3 border rounded-md bg-card space-y-2">
                                            <div className="flex justify-between items-center">
                                                <Label htmlFor={`choice-text-${choice.id}`}>Choice Text</Label>
                                                <Button variant="ghost" size="icon" onClick={() => handleRemoveChoice(scene.id, choice.id)} className="h-6 w-6">
                                                    <Trash2 className="h-4 w-4 text-red-500" />
                                                </Button>
                                            </div>
                                            <Input id={`choice-text-${choice.id}`} value={choice.text} onChange={(e) => handleChoiceChange(scene.id, choice.id, 'text', e.target.value)} placeholder="e.g., Offer to help"/>
                                             <div className="flex items-center gap-2">
                                                <ChevronsRight className="h-4 w-4 text-muted-foreground"/>
                                                <Select value={choice.nextSceneId || ''} onValueChange={(val) => handleChoiceChange(scene.id, choice.id, 'nextSceneId', val)}>
                                                    <SelectTrigger>
                                                        <SelectValue placeholder="Leads to..." />
                                                    </SelectTrigger>
                                                    <SelectContent>
                                                        {scenes.filter(s => s.id !== scene.id).map(s => <SelectItem key={s.id} value={s.id}>{s.title}</SelectItem>)}
                                                    </SelectContent>
                                                </Select>
                                            </div>
                                        </div>
                                    ))}
                                    {!scene.isEnding && (
                                        <Button variant="outline" size="sm" onClick={() => handleAddChoice(scene.id)}>
                                            <PlusCircle className="mr-2 h-4 w-4"/> Add Choice
                                        </Button>
                                    )}
                                </div>
                            </div>
                        </Card>
                    ))}

                    <Button variant="outline" onClick={handleAddScene}>
                        <GitBranch className="mr-2 h-4 w-4" /> Add Scene
                    </Button>
                </CardContent>
            </Card>

             <Card>
                <CardHeader>
                    <CardTitle>Settings</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="flex items-center justify-between rounded-lg border p-4">
                         <div className="space-y-0.5">
                            <Label>Status</Label>
                            <p className="text-sm text-muted-foreground">Make this activity available to students.</p>
                         </div>
                         <Switch checked={activity.status === 'Published'} onCheckedChange={handleStatusChange} />
                    </div>
                </CardContent>
                <CardFooter>
                    <Button onClick={handleSave} className="ml-auto">
                        <Save className="mr-2 h-4 w-4" /> Save Activity
                    </Button>
                </CardFooter>
            </Card>
        </div>
    );
}

    