
'use client';

import { useState, useEffect, use } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft, Save, PlusCircle, Trash2 } from 'lucide-react';
import Link from 'next/link';
import type { Activity } from '@/app/admin/activities/page';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';

type Option = {
    id: string;
    text: string;
    isCorrect: boolean;
};

type Question = {
    id: string;
    text: string;
    options: Option[];
    correctFeedback?: string;
    incorrectFeedback?: string;
}

export default function QuestionSetEditPage({ params }: { params: Promise<{ id: string }> }) {
    const { id: activityId } = use(params);
    const [activity, setActivity] = useState<Activity | null>(null);
    const [questions, setQuestions] = useState<Question[]>([]);
    const { toast } = useToast();

    useEffect(() => {
        const savedActivities = localStorage.getItem('adminActivities');
        if (savedActivities) {
            const activities: Activity[] = JSON.parse(savedActivities);
            const currentActivity = activities.find(a => a.id === activityId);
            if (currentActivity) {
                setActivity(currentActivity);
                setQuestions(currentActivity.content?.questions || []);
            }
        }
    }, [activityId]);

    const handleAddQuestion = () => {
        setQuestions([...questions, {
            id: String(Date.now()),
            text: '',
            options: [
                { id: String(Date.now() + 1), text: '', isCorrect: false },
                { id: String(Date.now() + 2), text: '', isCorrect: false },
            ],
            correctFeedback: '',
            incorrectFeedback: '',
        }]);
    };

    const handleRemoveQuestion = (qId: string) => {
        setQuestions(questions.filter(q => q.id !== qId));
    };
    
    const handleQuestionChange = (qId: string, field: 'text' | 'correctFeedback' | 'incorrectFeedback', value: string) => {
        setQuestions(questions.map(q => q.id === qId ? { ...q, [field]: value } : q));
    };

    const handleAddOption = (qId: string) => {
        setQuestions(questions.map(q => {
            if (q.id === qId && q.options.length < 5) {
                return { ...q, options: [...q.options, { id: String(Date.now()), text: '', isCorrect: false }] };
            }
            return q;
        }));
    };
    
    const handleRemoveOption = (qId: string, oId: string) => {
         setQuestions(questions.map(q => {
            if (q.id === qId) {
                if (q.options.length <= 2) {
                    toast({ variant: 'destructive', title: 'Minimum 2 options required.' });
                    return q;
                }
                return { ...q, options: q.options.filter(o => o.id !== oId) };
            }
            return q;
        }));
    };

    const handleOptionTextChange = (qId: string, oId: string, text: string) => {
        setQuestions(questions.map(q => q.id === qId 
            ? { ...q, options: q.options.map(o => o.id === oId ? { ...o, text } : o) }
            : q
        ));
    };

    const handleOptionCorrectChange = (qId: string, oId: string, checked: boolean) => {
         setQuestions(questions.map(q => q.id === qId 
            ? { ...q, options: q.options.map(o => o.id === oId ? { ...o, isCorrect: checked } : o) }
            : q
        ));
    };

    const handleSave = () => {
        if (!activity) return;

        const updatedActivity = {
            ...activity,
            content: { questions },
        };

        const savedActivities = localStorage.getItem('adminActivities');
        if (savedActivities) {
            let activities: Activity[] = JSON.parse(savedActivities);
            activities = activities.map(a => a.id === activityId ? updatedActivity : a);
            localStorage.setItem('adminActivities', JSON.stringify(activities));
            setActivity(updatedActivity);
            toast({
                title: 'Activity Saved!',
                description: `"${activity.title}" has been successfully saved.`,
            });
        }
    };

    const handleActivityDetailsChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        if (!activity) return;
        const { name, value } = e.target;
        setActivity({ ...activity, [name]: value });
    }

    const handleStatusChange = (checked: boolean) => {
        if (!activity) return;
        const newStatus = checked ? 'Published' : 'Draft';
        setActivity(prev => prev ? { ...prev, status: newStatus } : null);
    };

    if (!activity) {
        return <div>Loading activity...</div>;
    }
    
    return (
         <div className="grid gap-4 md:gap-8">
            <div className="flex items-center gap-4">
                 <Button asChild variant="outline" size="icon">
                    <Link href="/admin/activities">
                        <ArrowLeft className="h-4 w-4" />
                    </Link>
                </Button>
                <h1 className="text-2xl font-bold">Edit: {activity.title}</h1>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>Activity Details</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="space-y-2">
                        <Label htmlFor="title">Activity Title</Label>
                        <Input id="title" name="title" value={activity.title} onChange={handleActivityDetailsChange} />
                    </div>
                     <div className="space-y-2">
                        <Label htmlFor="instructions">Instructions</Label>
                        <Textarea id="instructions" name="instructions" value={activity.instructions} onChange={handleActivityDetailsChange} placeholder="Enter instructions for the student." />
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Content Creator</CardTitle>
                    <CardDescription>Create the "Question Set" activity content.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    {questions.map((q, qIndex) => (
                        <div key={q.id} className="p-4 border rounded-md space-y-4 relative">
                            <Button variant="ghost" size="icon" className="absolute top-2 right-2" onClick={() => handleRemoveQuestion(q.id)}>
                                <Trash2 className="h-4 w-4 text-red-500" />
                            </Button>
                            <div className="space-y-2">
                                <Label htmlFor={`q-text-${q.id}`}>Question {qIndex + 1}</Label>
                                <Textarea id={`q-text-${q.id}`} value={q.text} onChange={(e) => handleQuestionChange(q.id, 'text', e.target.value)} placeholder="e.g., What should you do next?" />
                            </div>
                            <div className="space-y-2 pl-4">
                                <Label>Options</Label>
                                {q.options.map((opt, oIndex) => (
                                    <div key={opt.id} className="flex items-center gap-2">
                                        <Checkbox
                                            id={`correct-${opt.id}`}
                                            checked={opt.isCorrect}
                                            onCheckedChange={(checked) => handleOptionCorrectChange(q.id, opt.id, !!checked)}
                                        />
                                        <Input
                                            id={`option-${opt.id}`}
                                            value={opt.text}
                                            onChange={(e) => handleOptionTextChange(q.id, opt.id, e.target.value)}
                                            placeholder={`Option ${oIndex + 1}`}
                                        />
                                        <Button variant="ghost" size="icon" onClick={() => handleRemoveOption(q.id, opt.id)}>
                                            <Trash2 className="h-4 w-4 text-red-500" />
                                        </Button>
                                    </div>
                                ))}
                                <Button variant="outline" size="sm" onClick={() => handleAddOption(q.id)}>
                                    <PlusCircle className="mr-2 h-4 w-4" /> Add Option
                                </Button>
                            </div>
                            <div className="space-y-2 pl-4">
                                <Label>Feedback (Optional)</Label>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <Textarea value={q.correctFeedback} onChange={(e) => handleQuestionChange(q.id, 'correctFeedback', e.target.value)} placeholder="Feedback for correct answer" rows={2}/>
                                    <Textarea value={q.incorrectFeedback} onChange={(e) => handleQuestionChange(q.id, 'incorrectFeedback', e.target.value)} placeholder="Feedback for incorrect answer" rows={2}/>
                                </div>
                            </div>
                        </div>
                    ))}
                    <Button variant="outline" onClick={handleAddQuestion}>
                        <PlusCircle className="mr-2 h-4 w-4" /> Add Question
                    </Button>
                </CardContent>
            </Card>

             <Card>
                <CardHeader>
                    <CardTitle>Settings</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="flex items-center justify-between rounded-lg border p-4">
                         <div className="space-y-0.5">
                            <Label>Status</Label>
                            <p className="text-sm text-muted-foreground">
                                Make this activity available to students.
                            </p>
                         </div>
                         <Switch
                            checked={activity.status === 'Published'}
                            onCheckedChange={handleStatusChange}
                        />
                    </div>
                </CardContent>
                <CardFooter>
                    <Button onClick={handleSave} className="ml-auto">
                        <Save className="mr-2 h-4 w-4" /> Save Activity
                    </Button>
                </CardFooter>
            </Card>
        </div>
    );
}
