
'use client';

import { useState, useEffect, use } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft, Save, PlusCircle, Trash2 } from 'lucide-react';
import Link from 'next/link';
import type { Activity } from '@/app/admin/activities/page';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';

type Option = {
    id: number;
    text: string;
    isCorrect: boolean;
};

export default function MultipleChoiceEditPage({ params }: { params: Promise<{ id:string }> }) {
    const { id: activityId } = use(params);
    const [activity, setActivity] = useState<Activity | null>(null);
    const [question, setQuestion] = useState('');
    const [correctFeedback, setCorrectFeedback] = useState('');
    const [incorrectFeedback, setIncorrectFeedback] = useState('');
    const [options, setOptions] = useState<Option[]>([
        { id: 1, text: '', isCorrect: false },
        { id: 2, text: '', isCorrect: false },
    ]);
    const { toast } = useToast();

    useEffect(() => {
        const savedActivities = localStorage.getItem('adminActivities');
        if (savedActivities) {
            const activities: Activity[] = JSON.parse(savedActivities);
            const currentActivity = activities.find(a => a.id === activityId);
            if (currentActivity) {
                setActivity(currentActivity);
                setQuestion(currentActivity.content?.question || '');
                setCorrectFeedback(currentActivity.content?.correctFeedback || '');
                setIncorrectFeedback(currentActivity.content?.incorrectFeedback || '');
                setOptions(currentActivity.content?.options || [
                    { id: 1, text: '', isCorrect: false },
                    { id: 2, text: '', isCorrect: false },
                ]);
            }
        }
    }, [activityId]);

    const handleOptionChange = (id: number, text: string) => {
        setOptions(options.map(opt => opt.id === id ? { ...opt, text } : opt));
    };

    const handleCorrectChange = (id: number, checked: boolean) => {
        setOptions(options.map(opt => opt.id === id ? { ...opt, isCorrect: checked } : opt));
    };

    const handleAddOption = () => {
        if (options.length >= 5) {
            toast({ variant: "destructive", title: "Maximum options reached" });
            return;
        }
        setOptions([...options, { id: Date.now(), text: '', isCorrect: false }]);
    };
    
    const handleRemoveOption = (id: number) => {
        if (options.length <= 2) {
            toast({ variant: "destructive", title: "Minimum options required", description: "You must have at least two options." });
            return;
        }
        setOptions(options.filter(opt => opt.id !== id));
    };

    const handleSave = () => {
        if (!activity) return;

        const updatedActivity = {
            ...activity,
            content: { question, options, correctFeedback, incorrectFeedback },
        };

        const savedActivities = localStorage.getItem('adminActivities');
        if (savedActivities) {
            let activities: Activity[] = JSON.parse(savedActivities);
            activities = activities.map(a => a.id === activityId ? updatedActivity : a);
            localStorage.setItem('adminActivities', JSON.stringify(activities));
            setActivity(updatedActivity);
            toast({
                title: 'Activity Saved!',
                description: `"${activity.title}" has been successfully saved.`,
            });
        }
    };
    
    const handleActivityDetailsChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        if (!activity) return;
        const { name, value } = e.target;
        setActivity({ ...activity, [name]: value });
    }

    const handleStatusChange = (checked: boolean) => {
        if (!activity) return;
        const newStatus = checked ? 'Published' : 'Draft';
        setActivity(prev => prev ? { ...prev, status: newStatus } : null);
    };

    if (!activity) {
        return <div>Loading activity...</div>;
    }
    
    return (
         <div className="grid gap-4 md:gap-8">
            <div className="flex items-center gap-4">
                 <Button asChild variant="outline" size="icon">
                    <Link href="/admin/activities">
                        <ArrowLeft className="h-4 w-4" />
                    </Link>
                </Button>
                <h1 className="text-2xl font-bold">Edit: {activity.title}</h1>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>Activity Details</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="space-y-2">
                        <Label htmlFor="title">Activity Title</Label>
                        <Input id="title" name="title" value={activity.title} onChange={handleActivityDetailsChange} />
                    </div>
                     <div className="space-y-2">
                        <Label htmlFor="instructions">Instructions</Label>
                        <Textarea id="instructions" name="instructions" value={activity.instructions} onChange={handleActivityDetailsChange} placeholder="Enter instructions for the student." />
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Content Creator</CardTitle>
                    <CardDescription>Create the "Multiple Choice" activity content.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="space-y-2">
                        <Label htmlFor="question">1. Write your question</Label>
                        <Textarea
                            id="question"
                            value={question}
                            onChange={(e) => setQuestion(e.target.value)}
                            placeholder="e.g., What is the most important value when dealing with friends?"
                            rows={3}
                        />
                    </div>
                    
                    <div className="space-y-4">
                        <Label>2. Provide options and select the correct one(s)</Label>
                        {options.map((option, index) => (
                            <div key={option.id} className="flex items-center gap-2">
                                <Checkbox
                                    id={`correct-${option.id}`}
                                    checked={option.isCorrect}
                                    onCheckedChange={(checked) => handleCorrectChange(option.id, !!checked)}
                                />
                                <Input
                                    id={`option-${option.id}`}
                                    value={option.text}
                                    onChange={(e) => handleOptionChange(option.id, e.target.value)}
                                    placeholder={`Option ${index + 1}`}
                                />
                                <Button variant="ghost" size="icon" onClick={() => handleRemoveOption(option.id)}>
                                    <Trash2 className="h-4 w-4 text-red-500" />
                                </Button>
                            </div>
                        ))}
                         <Button variant="outline" size="sm" onClick={handleAddOption}>
                            <PlusCircle className="mr-2 h-4 w-4" /> Add Option
                        </Button>
                    </div>

                    <div className="space-y-4">
                        <Label>3. Add feedback (Optional)</Label>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <Label htmlFor="correctFeedback">Feedback for Correct Answer</Label>
                                <Textarea
                                    id="correctFeedback"
                                    value={correctFeedback}
                                    onChange={(e) => setCorrectFeedback(e.target.value)}
                                    placeholder="e.g., Great job! Honesty is key."
                                    rows={2}
                                />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="incorrectFeedback">Feedback for Incorrect Answer</Label>
                                <Textarea
                                    id="incorrectFeedback"
                                    value={incorrectFeedback}
                                    onChange={(e) => setIncorrectFeedback(e.target.value)}
                                    placeholder="e.g., Not quite. Think about what it means to be a good friend."
                                    rows={2}
                                />
                            </div>
                        </div>
                    </div>
                </CardContent>
            </Card>

             <Card>
                <CardHeader>
                    <CardTitle>Settings</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="flex items-center justify-between rounded-lg border p-4">
                         <div className="space-y-0.5">
                            <Label>Status</Label>
                            <p className="text-sm text-muted-foreground">
                                Make this activity available to students.
                            </p>
                         </div>
                         <Switch
                            checked={activity.status === 'Published'}
                            onCheckedChange={handleStatusChange}
                        />
                    </div>
                </CardContent>
                <CardFooter>
                    <Button onClick={handleSave} className="ml-auto">
                        <Save className="mr-2 h-4 w-4" /> Save Activity
                    </Button>
                </CardFooter>
            </Card>
        </div>
    );
}
