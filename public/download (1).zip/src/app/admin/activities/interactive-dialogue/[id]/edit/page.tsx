
'use client';

import { useState, useEffect, use } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft, Save, PlusCircle, Trash2 } from 'lucide-react';
import Link from 'next/link';
import type { Activity } from '@/app/admin/activities/page';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { type Character } from '@/app/admin/characters/page';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

type DialogueLine = {
    id: string;
    characterId: string;
    line: string;
};

export default function InteractiveDialogueEditPage({ params }: { params: Promise<{ id: string }> }) {
    const { id: activityId } = use(params);
    const [activity, setActivity] = useState<Activity | null>(null);
    const [dialogue, setDialogue] = useState<DialogueLine[]>([]);
    const [characters, setCharacters] = useState<Character[]>([]);
    const { toast } = useToast();

    useEffect(() => {
        const savedActivities = localStorage.getItem('adminActivities');
        if (savedActivities) {
            const activities: Activity[] = JSON.parse(savedActivities);
            const currentActivity = activities.find(a => a.id === activityId);
            if (currentActivity) {
                setActivity(currentActivity);
                setDialogue(currentActivity.content?.dialogue || []);
            }
        }

        const savedCharacters = localStorage.getItem('characters');
        if (savedCharacters) {
            setCharacters(JSON.parse(savedCharacters));
        }
    }, [activityId]);

    const handleLineChange = (id: string, field: 'characterId' | 'line', value: string) => {
        setDialogue(dialogue.map(line => line.id === id ? { ...line, [field]: value } : line));
    };

    const handleAddLine = () => {
        if (characters.length === 0) {
            toast({
                title: "No Characters Found",
                description: "Please create at least one character before adding dialogue.",
                variant: "destructive"
            });
            return;
        }
        setDialogue([...dialogue, { id: String(Date.now()), characterId: characters[0].id, line: '' }]);
    };
    
    const handleRemoveLine = (id: string) => {
        setDialogue(dialogue.filter(line => line.id !== id));
    };

    const handleSave = () => {
        if (!activity) return;

        const updatedActivity = {
            ...activity,
            content: { dialogue },
        };

        const savedActivities = localStorage.getItem('adminActivities');
        if (savedActivities) {
            let activities: Activity[] = JSON.parse(savedActivities);
            activities = activities.map(a => a.id === activityId ? updatedActivity : a);
            localStorage.setItem('adminActivities', JSON.stringify(activities));
            setActivity(updatedActivity);
            toast({
                title: 'Activity Saved!',
                description: `"${activity.title}" has been successfully saved.`,
            });
        }
    };

    const handleActivityDetailsChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        if (!activity) return;
        const { name, value } = e.target;
        setActivity({ ...activity, [name]: value });
    }

    const handleStatusChange = (checked: boolean) => {
        if (!activity) return;
        const newStatus = checked ? 'Published' : 'Draft';
        setActivity(prev => prev ? { ...prev, status: newStatus } : null);
    };

    if (!activity) {
        return <div>Loading activity...</div>;
    }
    
    return (
         <div className="grid gap-4 md:gap-8">
            <div className="flex items-center gap-4">
                 <Button asChild variant="outline" size="icon">
                    <Link href="/admin/activities">
                        <ArrowLeft className="h-4 w-4" />
                    </Link>
                </Button>
                <h1 className="text-2xl font-bold">Edit: {activity.title}</h1>
            </div>
            
            <Card>
                <CardHeader>
                    <CardTitle>Activity Details</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="space-y-2">
                        <Label htmlFor="title">Activity Title</Label>
                        <Input id="title" name="title" value={activity.title} onChange={handleActivityDetailsChange} />
                    </div>
                     <div className="space-y-2">
                        <Label htmlFor="instructions">Instructions</Label>
                        <Textarea id="instructions" name="instructions" value={activity.instructions} onChange={handleActivityDetailsChange} placeholder="Enter instructions for the student." />
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Content Creator</CardTitle>
                    <CardDescription>Create the "Interactive Dialogue" content.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="space-y-4">
                        <Label>Dialogue Lines</Label>
                        {dialogue.map((line, index) => {
                            const character = characters.find(c => c.id === line.characterId);
                            return (
                            <div key={line.id} className="p-4 border rounded-md space-y-2 relative">
                                <div className="absolute top-2 right-2 flex items-center">
                                    <span className="text-xs text-muted-foreground mr-2">Line {index + 1}</span>
                                    <Button variant="ghost" size="icon" onClick={() => handleRemoveLine(line.id)}>
                                        <Trash2 className="h-4 w-4 text-red-500" />
                                    </Button>
                                </div>
                                <div className="flex gap-4 items-start">
                                    <div className="flex flex-col items-center gap-2">
                                        <Avatar>
                                            <AvatarImage src={character?.avatar} />
                                            <AvatarFallback>{character?.name.charAt(0) || '?'}</AvatarFallback>
                                        </Avatar>
                                        <Select value={line.characterId} onValueChange={(value) => handleLineChange(line.id, 'characterId', value)}>
                                            <SelectTrigger className="w-[120px]">
                                                <SelectValue placeholder="Select Character" />
                                            </SelectTrigger>
                                            <SelectContent>
                                                {characters.map(char => (
                                                    <SelectItem key={char.id} value={char.id}>{char.name}</SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                    </div>
                                    <div className="flex-1 space-y-1">
                                        <Label htmlFor={`line-${line.id}`}>Dialogue</Label>
                                        <Textarea id={`line-${line.id}`} value={line.line} onChange={(e) => handleLineChange(line.id, 'line', e.target.value)} placeholder="Enter dialogue line..." rows={3} />
                                    </div>
                                </div>
                            </div>
                        )})}
                         <Button variant="outline" size="sm" onClick={handleAddLine}>
                            <PlusCircle className="mr-2 h-4 w-4" /> Add Line
                        </Button>
                    </div>
                </CardContent>
            </Card>

             <Card>
                <CardHeader>
                    <CardTitle>Settings</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="flex items-center justify-between rounded-lg border p-4">
                         <div className="space-y-0.5">
                            <Label>Status</Label>
                            <p className="text-sm text-muted-foreground">
                                Make this activity available to students.
                            </p>
                         </div>
                         <Switch
                            checked={activity.status === 'Published'}
                            onCheckedChange={handleStatusChange}
                        />
                    </div>
                </CardContent>
                <CardFooter>
                    <Button onClick={handleSave} className="ml-auto">
                        <Save className="mr-2 h-4 w-4" /> Save Activity
                    </Button>
                </CardFooter>
            </Card>
        </div>
    );
}
