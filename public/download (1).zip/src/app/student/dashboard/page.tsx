import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Award, BookOpen, Trophy } from "lucide-react";
import Link from "next/link";

const ongoingCourses = [
  { title: "The Power of Empathy", progress: 75, unit: "Unit 4/6" },
  { title: "Developing Resilience", progress: 40, unit: "Unit 2/6" },
  { title: "The Art of Kindness", progress: 90, unit: "Unit 5/6" },
];

const badges = [
  { name: "Kindness Champion", icon: <Award className="h-8 w-8 text-yellow-500" /> },
  { name: "Empathy Expert", icon: <Award className="h-8 w-8 text-blue-500" /> },
  { name: "First Steps", icon: <Award className="h-8 w-8 text-green-500" /> },
  { name: "Team Player", icon: <Award className="h-8 w-8 text-purple-500" /> },
];

const leaderboard = [
    { rank: 1, name: "Sofia P.", points: 1250, avatar: "https://placehold.co/40x40.png?text=SP" },
    { rank: 2, name: "Liam K.", points: 1100, avatar: "https://placehold.co/40x40.png?text=LK" },
    { rank: 3, name: "You", points: 980, avatar: "https://placehold.co/40x40.png?text=ME" },
    { rank: 4, name: "Olivia G.", points: 950, avatar: "https://placehold.co/40x40.png?text=OG" },
    { rank: 5, name: "Noah B.", points: 870, avatar: "https://placehold.co/40x40.png?text=NB" },
];

export default function StudentDashboardPage() {
  return (
    <div className="grid gap-4 md:gap-8">
        <Card>
            <CardHeader>
                <CardTitle className="text-xl sm:text-2xl">Welcome back, Alex!</CardTitle>
                <CardDescription>Keep up the great work. Here&apos;s a summary of your progress.</CardDescription>
            </CardHeader>
        </Card>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 lg:gap-8">
        <Card>
          <CardHeader>
            <CardTitle>My Progress</CardTitle>
            <CardDescription>Character Traits</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex justify-between mb-1">
                <span className="text-sm font-medium">Empathy</span>
                <span className="text-sm text-muted-foreground">75%</span>
              </div>
              <Progress value={75} aria-label="Empathy progress" />
            </div>
            <div>
              <div className="flex justify-between mb-1">
                <span className="text-sm font-medium">Resilience</span>
                <span className="text-sm text-muted-foreground">40%</span>
              </div>
              <Progress value={40} aria-label="Resilience progress" />
            </div>
            <div>
              <div className="flex justify-between mb-1">
                <span className="text-sm font-medium">Kindness</span>
                <span className="text-sm text-muted-foreground">90%</span>
              </div>
              <Progress value={90} aria-label="Kindness progress" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="lg:col-span-2">
            <CardHeader className="flex flex-row items-center justify-between">
                <div>
                    <CardTitle>Ongoing Courses</CardTitle>
                    <CardDescription>Continue your learning journey.</CardDescription>
                </div>
                <Button asChild variant="outline" size="sm">
                    <Link href="/courses">View All</Link>
                </Button>
            </CardHeader>
            <CardContent>
                <div className="space-y-4">
                {ongoingCourses.map((course) => (
                    <div key={course.title}>
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                        <div className="flex items-center gap-3">
                        <div className="bg-primary/10 p-2 rounded-md">
                            <BookOpen className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                            <p className="font-medium">{course.title}</p>
                            <p className="text-sm text-muted-foreground">{course.unit}</p>
                        </div>
                        </div>
                        <div className="w-full sm:w-1/4 text-left sm:text-right">
                        <p className="text-sm font-medium">{course.progress}%</p>
                        <Progress value={course.progress} className="h-2 mt-1" />
                        </div>
                    </div>
                    </div>
                ))}
                </div>
            </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-3 lg:gap-8">
        <Card className="lg:col-span-2">
            <CardHeader>
                <CardTitle>Leaderboard</CardTitle>
                <CardDescription>See how you rank among your peers.</CardDescription>
            </CardHeader>
            <CardContent>
                <Table>
                <TableHeader>
                    <TableRow>
                    <TableHead className="w-[50px]">Rank</TableHead>
                    <TableHead>Student</TableHead>
                    <TableHead className="text-right">Points</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {leaderboard.map((student) => (
                    <TableRow key={student.rank} className={student.name === 'You' ? 'bg-secondary' : ''}>
                        <TableCell className="font-medium">{student.rank}</TableCell>
                        <TableCell>
                        <div className="flex items-center gap-2">
                            <Avatar className="h-8 w-8">
                                <AvatarImage src={student.avatar} />
                                <AvatarFallback>{student.name.substring(0,2)}</AvatarFallback>
                            </Avatar>
                            <span>{student.name}</span>
                        </div>
                        </TableCell>
                        <TableCell className="text-right font-semibold">{student.points}</TableCell>
                    </TableRow>
                    ))}
                </TableBody>
                </Table>
            </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>My Badges</CardTitle>
            <CardDescription>Achievements you&apos;ve unlocked.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-4">
              {badges.map((badge, i) => (
                <div key={i} className="flex flex-col items-center text-center gap-2">
                  {badge.icon}
                  <p className="text-xs font-medium">{badge.name}</p>
                </div>
              ))}
               <div className="flex flex-col items-center text-center gap-2 opacity-50">
                  <Trophy className="h-8 w-8 text-muted-foreground" />
                  <p className="text-xs font-medium">Explorer</p>
                </div>
                 <div className="flex flex-col items-center text-center gap-2 opacity-50">
                  <Trophy className="h-8 w-8 text-muted-foreground" />
                  <p className="text-xs font-medium">Communicator</p>
                </div>
            </div>
          </CardContent>
           <CardFooter>
                <Button variant="outline" className="w-full">View All Badges</Button>
            </CardFooter>
        </Card>
      </div>
    </div>
  );
}
