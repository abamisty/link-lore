
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Award, CheckCircle, TrendingUp, Trophy } from "lucide-react";
import { Progress } from "@/components/ui/progress";

const progressData = {
    totalPoints: 0,
    coursesCompleted: 0,
    lessonsCompleted: 0,
    badgesEarned: 0,
};

const traitProgress = [
    { name: 'Empathy', progress: 0, points: 0 },
    { name: 'Resilience', progress: 0, points: 0 },
    { name: 'Kindness', progress: 0, points: 0 },
    { name: 'Integrity', progress: 0, points: 0 },
    { name: 'Decision Making', progress: 0, points: 0 },
];

const recentActivity: any[] = [];

export default function StudentProgressPage() {
    return (
        <div className="grid gap-4 md:gap-8">
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Total Character Points</CardTitle>
                        <Award className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{progressData.totalPoints}</div>
                        <p className="text-xs text-muted-foreground">Get started by completing a lesson!</p>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Lessons Completed</CardTitle>
                        <CheckCircle className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{progressData.lessonsCompleted}</div>
                         <p className="text-xs text-muted-foreground">in 0 courses</p>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Badges Earned</CardTitle>
                        <Trophy className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{progressData.badgesEarned}</div>
                        <p className="text-xs text-muted-foreground">No badges earned yet.</p>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Current Rank</CardTitle>
                        <TrendingUp className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">N/A</div>
                        <p className="text-xs text-muted-foreground">Complete lessons to get ranked.</p>
                    </CardContent>
                </Card>
            </div>

            <div className="grid gap-4 lg:grid-cols-5 lg:gap-8">
                <Card className="lg:col-span-2">
                    <CardHeader>
                        <CardTitle>Character Trait Progress</CardTitle>
                        <CardDescription>Points earned and progress in each key area.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                        {traitProgress.map(trait => (
                            <div key={trait.name}>
                                <div className="flex justify-between items-center mb-1">
                                    <span className="text-sm font-medium">{trait.name}</span>
                                    <span className="text-sm font-bold text-primary">{trait.points} pts</span>
                                </div>
                                <Progress value={trait.progress} />
                            </div>
                        ))}
                    </CardContent>
                </Card>

                <Card className="lg:col-span-3">
                    <CardHeader>
                        <CardTitle>Recent Activity</CardTitle>
                        <CardDescription>A log of your latest achievements and completed tasks.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Date</TableHead>
                                    <TableHead>Activity</TableHead>
                                    <TableHead>Course</TableHead>
                                    <TableHead className="text-right">Points</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {recentActivity.length > 0 ? recentActivity.map((activity, index) => (
                                    <TableRow key={index}>
                                        <TableCell className="hidden md:table-cell">{activity.date}</TableCell>
                                        <TableCell>{activity.description}</TableCell>
                                        <TableCell className="hidden sm:table-cell">{activity.course}</TableCell>
                                        <TableCell className="text-right font-semibold text-green-600">
                                            {activity.points > 0 ? `+${activity.points}` : ''}
                                        </TableCell>
                                    </TableRow>
                                )) : (
                                    <TableRow>
                                        <TableCell colSpan={4} className="text-center h-24">No activity yet. Go start a course!</TableCell>
                                    </TableRow>
                                )}
                            </TableBody>
                        </Table>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}
