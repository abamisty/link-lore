
'use client';

import { useState, useEffect, use, useRef } from 'react';
import type { Activity } from '@/app/admin/activities/page';
import { Button } from '@/components/ui/button';
import { CheckCircle, RefreshCw } from 'lucide-react';
import { cn } from '@/lib/utils';

type Word = {
    text: string;
    isBlank: boolean;
};

interface DragTheWordsPlayerProps {
    params: Promise<{ id: string }>;
    isPreview?: boolean;
    onComplete?: () => void;
}

export default function DragTheWordsPlayer({ params, onComplete }: DragTheWordsPlayerProps) {
    const { id: activityId } = use(params);
    const [activity, setActivity] = useState<Activity | null>(null);
    const [words, setWords] = useState<Word[]>([]);
    const [blanks, setBlanks] = useState<string[]>([]);
    const [filledBlanks, setFilledBlanks] = useState<(string | null)[]>([]);
    const [isSubmitted, setIsSubmitted] = useState(false);
    const [draggedItem, setDraggedItem] = useState<string | null>(null);
    const [dragSource, setDragSource] = useState<'bank' | number | null>(null);
    const blankRefs = useRef<(HTMLSpanElement | null)[]>([]);

    useEffect(() => {
        const savedActivities = localStorage.getItem('adminActivities');
        if (savedActivities) {
            const activities: Activity[] = JSON.parse(savedActivities);
            const currentActivity = activities.find(a => a.id === activityId);
            if (currentActivity) {
                setActivity(currentActivity);
                initializeState(currentActivity);
            }
        }
    }, [activityId]);
    
    const initializeState = (activity: Activity) => {
        const contentWords: Word[] = activity.content?.words || [];
        setWords(contentWords);
        const blankWords = contentWords.filter(w => w.isBlank).map(w => w.text.replace(/[.,!?;:]$/, ''));
        setBlanks(blankWords);
        setFilledBlanks(Array(blankWords.length).fill(null));
        setIsSubmitted(false);
    }

    const handleDragStart = (e: React.DragEvent<HTMLDivElement>, item: string, source: 'bank' | number) => {
        setDraggedItem(item);
        setDragSource(source);
        e.dataTransfer.effectAllowed = 'move';
    };
    
    const handleDragOver = (e: React.DragEvent<HTMLSpanElement>, index: number) => {
        e.preventDefault();
        const target = blankRefs.current[index];
        if (target) {
            target.classList.add('bg-primary/20');
        }
    };
    
    const handleDragLeave = (e: React.DragEvent<HTMLSpanElement>, index: number) => {
        e.preventDefault();
        const target = blankRefs.current[index];
        if (target) {
            target.classList.remove('bg-primary/20');
        }
    };

    const handleDrop = (e: React.DragEvent<HTMLSpanElement>, blankIndex: number) => {
        e.preventDefault();
        const target = blankRefs.current[blankIndex];
        if (target) {
            target.classList.remove('bg-primary/20');
        }
        if (!draggedItem) return;

        const newFilledBlanks = [...filledBlanks];
        const newBlanks = [...blanks];
        
        // Word is coming from the bank
        if (dragSource === 'bank') {
            const itemIndexInBank = newBlanks.indexOf(draggedItem);
            newBlanks.splice(itemIndexInBank, 1);
        } 
        // Word is coming from another blank
        else if (typeof dragSource === 'number') {
            newFilledBlanks[dragSource] = null;
        }

        // If the target blank already has a word, move it back to the bank
        if (newFilledBlanks[blankIndex]) {
            newBlanks.push(newFilledBlanks[blankIndex]!);
        }
        
        newFilledBlanks[blankIndex] = draggedItem;

        setFilledBlanks(newFilledBlanks);
        setBlanks(newBlanks);
        setDraggedItem(null);
        setDragSource(null);
    };

    const handleSubmit = () => {
        setIsSubmitted(true);
        if(onComplete) onComplete();
    };

    const handleReset = () => {
        if(activity) initializeState(activity);
    }
    
    const isCorrect = (word: Word, blankIndex: number) => {
        if (!isSubmitted) return null;
        return filledBlanks[blankIndex]?.toLowerCase() === word.text.replace(/[.,!?;:]$/, '').toLowerCase();
    };

    if (!activity) return <div>Loading activity...</div>;

    let blankCounter = -1;

    return (
        <div>
            <div className="text-lg leading-relaxed p-4 border rounded-md bg-secondary/30">
                {words.map((word, index) => {
                    if (word.isBlank) {
                        blankCounter++;
                        const currentBlankIndex = blankCounter;
                        const isAnswerCorrect = isCorrect(word, currentBlankIndex);
                        return (
                            <span
                                key={index}
                                ref={el => blankRefs.current[currentBlankIndex] = el}
                                onDragOver={(e) => handleDragOver(e, currentBlankIndex)}
                                onDragLeave={(e) => handleDragLeave(e, currentBlankIndex)}
                                onDrop={(e) => handleDrop(e, currentBlankIndex)}
                                onDragStart={(e) => filledBlanks[currentBlankIndex] && handleDragStart(e, filledBlanks[currentBlankIndex]!, currentBlankIndex)}
                                draggable={!!filledBlanks[currentBlankIndex] && !isSubmitted}
                                className={cn(
                                    "inline-block w-32 h-8 mx-1 rounded-md transition-colors",
                                    "border-b-2 border-dashed border-primary/50 align-middle",
                                    filledBlanks[currentBlankIndex] ? 'cursor-grab bg-card border-solid border-2' : 'bg-transparent',
                                    isSubmitted && (isAnswerCorrect ? 'border-green-500' : 'border-red-500'),
                                )}
                            >
                                {filledBlanks[currentBlankIndex] &&
                                    <span className="flex items-center justify-center h-full text-base">{filledBlanks[currentBlankIndex]}</span>
                                }
                            </span>
                        );
                    } else {
                        return <span key={index}>{word.text}</span>;
                    }
                })}
            </div>

            <div 
                className="mt-6 p-4 border rounded-md bg-secondary/50 min-h-[80px] flex flex-wrap gap-2 justify-center items-center"
                onDragOver={(e) => e.preventDefault()}
                onDrop={(e) => {
                    if (dragSource !== 'bank') { // only allow drops back into the bank
                        handleReset(); // simplified reset logic on invalid drop
                    }
                }}
            >
                {blanks.map((word, index) => (
                    <div
                        key={`${word}-${index}`}
                        draggable={!isSubmitted}
                        onDragStart={(e) => handleDragStart(e, word, 'bank')}
                        className="px-3 py-1.5 rounded-md bg-card shadow-sm cursor-grab"
                    >
                        {word}
                    </div>
                ))}
            </div>
            
            <div className="flex gap-2 w-full mt-6">
                 <Button onClick={handleReset} variant="outline" className="w-full">
                    <RefreshCw className="mr-2 h-4 w-4" />
                    Reset
                </Button>
                <Button onClick={handleSubmit} className="w-full" disabled={isSubmitted}>
                    <CheckCircle className="mr-2 h-4 w-4" />
                    Check My Answers
                </Button>
            </div>
        </div>
    );
}
