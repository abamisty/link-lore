
'use client';

import { useState, useEffect, use } from 'react';
import { Button } from '@/components/ui/button';
import { CheckCircle } from 'lucide-react';
import type { Activity } from '@/app/admin/activities/page';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';

type Word = {
    text: string;
    isBlank: boolean;
};

type Answer = {
    original: string;
    attempt: string;
    isCorrect: boolean | null;
}

interface FillInTheBlanksPlayerProps {
    params: Promise<{ id: string }>;
    isPreview?: boolean;
    onComplete?: () => void;
}

export default function FillInTheBlanksPlayerPage({ params, onComplete }: FillInTheBlanksPlayerProps) {
    const { id: activityId } = use(params);
    const [activity, setActivity] = useState<Activity | null>(null);
    const [words, setWords] = useState<Word[]>([]);
    const [answers, setAnswers] = useState<Record<number, string>>({});
    const [results, setResults] = useState<Answer[]>([]);
    const [isSubmitted, setIsSubmitted] = useState(false);

    useEffect(() => {
        const savedActivities = localStorage.getItem('adminActivities');
        if (savedActivities) {
            const activities: Activity[] = JSON.parse(savedActivities);
            const currentActivity = activities.find(a => a.id === activityId);
            if (currentActivity) {
                setActivity(currentActivity);
                setWords(currentActivity.content?.words || []);
            }
        }
    }, [activityId]);

    const handleInputChange = (index: number, value: string) => {
        setAnswers(prev => ({ ...prev, [index]: value }));
    };

    const handleSubmit = () => {
        const newResults: Answer[] = [];
        let correctCount = 0;

        words.forEach((word, index) => {
            if (word.isBlank) {
                const attempt = answers[index] || '';
                const isCorrect = attempt.trim().toLowerCase() === word.text.toLowerCase().replace(/[.,!?;:]$/, '');
                if (isCorrect) correctCount++;
                newResults.push({ original: word.text, attempt, isCorrect });
            }
        });

        setResults(newResults);
        setIsSubmitted(true);
        if (onComplete) onComplete();
    };
    
    if (!activity) {
        return <div>Loading activity...</div>;
    }

    return (
        <div>
            <div className="text-lg leading-relaxed flex flex-wrap items-center gap-x-2 gap-y-4 p-4 border rounded-md bg-secondary/30">
                {(words || []).map((word, index) =>
                    word.isBlank ? (
                        <div key={index} className="inline-block">
                            <Input
                                type="text"
                                onChange={(e) => handleInputChange(index, e.target.value)}
                                disabled={isSubmitted}
                                className={cn(
                                    "w-32 h-8 text-base inline-block",
                                    isSubmitted && (results.find(r => r.original === word.text)?.isCorrect ? 'border-green-500 ring-green-500' : 'border-red-500 ring-red-500')
                                )}
                            />
                            {isSubmitted && !results.find(r => r.original === word.text)?.isCorrect && (
                                <span className="text-xs text-green-600 ml-1">({word.text})</span>
                            )}
                        </div>
                    ) : (
                        <span key={index}>{word.text}</span>
                    )
                )}
            </div>
             <Button onClick={handleSubmit} className="w-full mt-6" disabled={isSubmitted}>
                <CheckCircle className="mr-2 h-4 w-4" />
                Check My Answers
            </Button>
        </div>
    );
}
