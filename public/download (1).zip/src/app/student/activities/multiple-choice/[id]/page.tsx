
'use client';

import { useState, useEffect, use } from 'react';
import { Button } from '@/components/ui/button';
import { CheckCircle } from 'lucide-react';
import type { Activity } from '@/app/admin/activities/page';
import { cn } from '@/lib/utils';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';

type Option = {
    id: number;
    text: string;
    isCorrect: boolean;
};

interface MultipleChoicePlayerProps {
    params: Promise<{ id: string }>;
    isPreview?: boolean;
    onComplete?: () => void;
}

export default function MultipleChoicePlayerPage({ params, onComplete }: MultipleChoicePlayerProps) {
    const { id: activityId } = use(params);
    const [activity, setActivity] = useState<Activity | null>(null);
    const [question, setQuestion] = useState('');
    const [options, setOptions] = useState<Option[]>([]);
    const [selectedOptions, setSelectedOptions] = useState<Record<number, boolean>>({});
    const [isSubmitted, setIsSubmitted] = useState(false);
    const [feedback, setFeedback] = useState<string | null>(null);

    useEffect(() => {
        const savedActivities = localStorage.getItem('adminActivities');
        if (savedActivities) {
            const activities: Activity[] = JSON.parse(savedActivities);
            const currentActivity = activities.find(a => a.id === activityId);
            if (currentActivity) {
                setActivity(currentActivity);
                setQuestion(currentActivity.content?.question || '');
                setOptions(currentActivity.content?.options || []);
            }
        }
    }, [activityId]);

    const handleSelectionChange = (optionId: number, checked: boolean) => {
        setSelectedOptions(prev => ({...prev, [optionId]: checked }));
    };

    const handleSubmit = () => {
        let isFullyCorrect = true;
        if (Object.keys(selectedOptions).length === 0) {
            isFullyCorrect = false;
        } else {
            for (const option of options) {
                if ((selectedOptions[option.id] || false) !== option.isCorrect) {
                    isFullyCorrect = false;
                    break;
                }
            }
        }

        if (isFullyCorrect) {
            setFeedback(activity?.content?.correctFeedback || "That's correct!");
        } else {
            setFeedback(activity?.content?.incorrectFeedback || "That's not quite right. The correct answers are highlighted.");
        }
        
        setIsSubmitted(true);
        if(onComplete) onComplete();
    };

    const getOptionClass = (option: Option) => {
        if (!isSubmitted) return '';
        if (option.isCorrect) return 'bg-green-100 border-green-300';
        if (selectedOptions[option.id] && !option.isCorrect) return 'bg-red-100 border-red-300';
        return '';
    };

    if (!activity) {
        return <div>Loading activity...</div>;
    }

    return (
        <div>
            <p className="text-lg font-semibold mb-6">{question}</p>
            
            <div className="space-y-4">
                {(options || []).map(option => (
                    <div key={option.id} className={cn("flex items-center space-x-3 rounded-lg border p-4 transition-colors", getOptionClass(option))}>
                        <Checkbox
                            id={`option-${option.id}`}
                            checked={selectedOptions[option.id] || false}
                            onCheckedChange={(checked) => handleSelectionChange(option.id, !!checked)}
                            disabled={isSubmitted}
                        />
                        <Label htmlFor={`option-${option.id}`} className="flex-1 text-base cursor-pointer">
                            {option.text}
                        </Label>
                    </div>
                ))}
            </div>

             <Button onClick={handleSubmit} className="w-full mt-6" disabled={isSubmitted}>
                <CheckCircle className="mr-2 h-4 w-4" />
                {isSubmitted ? 'Submitted!' : 'Check My Answer'}
            </Button>

            {feedback && (
                <div className={cn("mt-4 p-4 rounded-md text-sm font-semibold", 
                    (feedback === (activity?.content?.correctFeedback || "That's correct!")) ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                )}>
                    {feedback}
                </div>
            )}
        </div>
    );
}
