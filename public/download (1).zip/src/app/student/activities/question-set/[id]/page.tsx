
'use client';

import { useState, useEffect, use } from 'react';
import type { Activity } from '@/app/admin/activities/page';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { ArrowLeft, ArrowRight, CheckCircle, RefreshCw } from 'lucide-react';
import { cn } from '@/lib/utils';

type Option = {
    id: string;
    text: string;
    isCorrect: boolean;
};

type Question = {
    id: string;
    text: string;
    options: Option[];
    correctFeedback?: string;
    incorrectFeedback?: string;
}

interface QuestionSetPlayerProps {
    params: Promise<{ id: string }>;
    isPreview?: boolean;
    onComplete?: () => void;
}

export default function QuestionSetPlayer({ params, onComplete }: QuestionSetPlayerProps) {
    const { id: activityId } = use(params);
    const [activity, setActivity] = useState<Activity | null>(null);
    const [questions, setQuestions] = useState<Question[]>([]);
    const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
    const [answers, setAnswers] = useState<Record<string, Record<string, boolean>>>({});
    const [results, setResults] = useState<Record<string, boolean | null>>({});
    const [isFinished, setIsFinished] = useState(false);

    useEffect(() => {
        const savedActivities = localStorage.getItem('adminActivities');
        if (savedActivities) {
            const activities: Activity[] = JSON.parse(savedActivities);
            const currentActivity = activities.find(a => a.id === activityId);
            if (currentActivity) {
                setActivity(currentActivity);
                setQuestions(currentActivity.content?.questions || []);
            }
        }
    }, [activityId]);

    const handleAnswerChange = (questionId: string, optionId: string, checked: boolean) => {
        setAnswers(prev => ({
            ...prev,
            [questionId]: {
                ...prev[questionId],
                [optionId]: checked,
            }
        }));
    };

    const checkAnswer = (question: Question) => {
        const questionAnswers = answers[question.id] || {};
        let isCorrect = true;
        if (Object.keys(questionAnswers).length === 0) {
            isCorrect = false;
        } else {
            for (const option of question.options) {
                const isSelected = questionAnswers[option.id] || false;
                if (option.isCorrect !== isSelected) {
                    isCorrect = false;
                    break;
                }
            }
        }
        setResults(prev => ({...prev, [question.id]: isCorrect }));
    };

    const handleNext = () => {
        checkAnswer(questions[currentQuestionIndex]);
        if (currentQuestionIndex < questions.length - 1) {
            setCurrentQuestionIndex(prev => prev + 1);
        } else {
            setIsFinished(true);
            if(onComplete) onComplete();
        }
    };
    
    const handlePrevious = () => {
        if (currentQuestionIndex > 0) {
            setCurrentQuestionIndex(prev => prev - 1);
        }
    }

    const handleRestart = () => {
        setCurrentQuestionIndex(0);
        setAnswers({});
        setResults({});
        setIsFinished(false);
    }
    
    const getOptionClass = (option: Option, questionId: string) => {
        if (!results[questionId === undefined]) return '';
        if (results[questionId] === null) return '';

        if (option.isCorrect) return 'bg-green-100 border-green-300';
        if ((answers[questionId]?.[option.id] || false) && !option.isCorrect) return 'bg-red-100 border-red-300';
        return '';
    };

    if (!activity) return <div>Loading...</div>;

    if (isFinished) {
        const correctCount = Object.values(results).filter(r => r === true).length;
        const totalCount = questions.length;
        return (
             <div className="text-center p-8">
                <h2 className="text-2xl font-bold mb-2">Quiz Complete!</h2>
                <p className="text-lg text-muted-foreground mb-4">You got {correctCount} out of {totalCount} questions correct.</p>
                <Button onClick={handleRestart}>
                    <RefreshCw className="mr-2 h-4 w-4" />
                    Try Again
                </Button>
            </div>
        )
    }

    const currentQuestion = questions[currentQuestionIndex];
    const isAnswered = results[currentQuestion?.id] !== undefined && results[currentQuestion?.id] !== null;

    return (
        <div>
            <div className="mb-4 text-sm text-muted-foreground">
                Question {currentQuestionIndex + 1} of {questions.length}
            </div>
            {currentQuestion ? (
                <Card>
                    <CardHeader>
                        <CardTitle>{currentQuestion.text}</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        {currentQuestion.options.map(option => (
                             <div key={option.id} className={cn("flex items-center space-x-3 rounded-lg border p-4 transition-colors", getOptionClass(option, currentQuestion.id))}>
                                <Checkbox
                                    id={`option-${option.id}`}
                                    checked={answers[currentQuestion.id]?.[option.id] || false}
                                    onCheckedChange={(checked) => handleAnswerChange(currentQuestion.id, option.id, !!checked)}
                                    disabled={isAnswered}
                                />
                                <Label htmlFor={`option-${option.id}`} className="flex-1 text-base cursor-pointer">
                                    {option.text}
                                </Label>
                            </div>
                        ))}

                        {isAnswered && (
                            <div className="p-4 rounded-md bg-secondary/50 text-sm">
                                {results[currentQuestion.id] ? 
                                    (<p className="text-green-700 font-semibold">{currentQuestion.correctFeedback || 'Correct!'}</p>) :
                                    (<p className="text-red-700 font-semibold">{currentQuestion.incorrectFeedback || 'Not quite, the correct answers are highlighted.'}</p>)
                                }
                            </div>
                        )}
                    </CardContent>
                </Card>
            ) : (
                <p>No questions in this set.</p>
            )}
            <div className="flex justify-between mt-6">
                <Button variant="outline" onClick={handlePrevious} disabled={currentQuestionIndex === 0}>
                    <ArrowLeft className="mr-2 h-4 w-4" /> Previous
                </Button>
                 <Button onClick={handleNext}>
                     {currentQuestionIndex < questions.length - 1 ? 'Next' : 'Finish'} 
                     <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
            </div>
        </div>
    );
}
