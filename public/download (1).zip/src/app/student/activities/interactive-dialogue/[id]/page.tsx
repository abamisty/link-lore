
'use client';

import { useState, useEffect, use, useRef } from 'react';
import type { Activity } from '@/app/admin/activities/page';
import { type Character } from '@/app/admin/characters/page';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';

interface InteractiveDialoguePlayerProps {
    params: Promise<{ id: string }>;
    isPreview?: boolean;
    onComplete?: () => void;
}

type DialogueLine = {
    id: string;
    characterId: string;
    line: string;
};

export default function InteractiveDialoguePlayer({ params, onComplete }: InteractiveDialoguePlayerProps) {
    const { id: activityId } = use(params);
    const [activity, setActivity] = useState<Activity | null>(null);
    const [characters, setCharacters] = useState<Character[]>([]);
    const [dialogue, setDialogue] = useState<DialogueLine[]>([]);
    const [currentLineIndex, setCurrentLineIndex] = useState(0);
    const dialogueContainerRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const savedActivities = localStorage.getItem('adminActivities');
        if (savedActivities) {
            const activities: Activity[] = JSON.parse(savedActivities);
            const currentActivity = activities.find(a => a.id === activityId);
            if (currentActivity) {
                setActivity(currentActivity);
                setDialogue(currentActivity.content?.dialogue || []);
            }
        }

        const savedCharacters = localStorage.getItem('characters');
        if (savedCharacters) {
            setCharacters(JSON.parse(savedCharacters));
        }
    }, [activityId]);

    useEffect(() => {
        // Scroll to the latest message
        if (dialogueContainerRef.current) {
            dialogueContainerRef.current.scrollTop = dialogueContainerRef.current.scrollHeight;
        }
    }, [currentLineIndex]);

    const handleNextLine = () => {
        if (currentLineIndex < dialogue.length - 1) {
            setCurrentLineIndex(prev => prev + 1);
        } else {
             if(onComplete) onComplete();
        }
    };
    
    if (!activity) return <div>Loading activity...</div>;

    const displayedDialogue = dialogue.slice(0, currentLineIndex + 1);

    return (
        <div className="w-full max-w-2xl mx-auto">
            <div ref={dialogueContainerRef} className="h-[400px] overflow-y-auto p-4 border rounded-md bg-secondary/30 space-y-6">
                {displayedDialogue.map((line, index) => {
                    const character = characters.find(c => c.id === line.characterId);
                    // A simple way to alternate character alignment
                    const isEven = characters.findIndex(c => c.id === line.characterId) % 2 === 0;

                    return (
                        <div key={line.id} className={`flex items-start gap-3 ${isEven ? 'flex-row-reverse' : ''}`}>
                            <Avatar>
                                <AvatarImage src={character?.avatar} />
                                <AvatarFallback>{character?.name.charAt(0)}</AvatarFallback>
                            </Avatar>
                            <div className={`p-3 rounded-lg max-w-sm ${isEven ? 'bg-primary text-primary-foreground' : 'bg-card'}`}>
                                <p className="font-bold text-sm mb-1">{character?.name}</p>
                                <p>{line.line}</p>
                            </div>
                        </div>
                    );
                })}
            </div>
            <Button onClick={handleNextLine} className="w-full mt-4">
                {currentLineIndex < dialogue.length - 1 ? 'Next' : 'Finish Dialogue'} <ArrowRight className="ml-2"/>
            </Button>
        </div>
    );
}
