
'use client';

import type { FC } from 'react';
import React, { useState, useEffect, use } from 'react';
import { Button } from '@/components/ui/button';
import { CheckCircle } from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import type { Activity } from '@/app/admin/activities/page';

type ValueItem = {
    id: string;
    text: string;
}

type ValuesState = {
    unassigned: ValueItem[];
    [key: string]: ValueItem[];
}

// Helper to shuffle an array
function shuffle<T>(array: T[]): T[] {
  let currentIndex = array.length, randomIndex;

  while (currentIndex !== 0) {
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex--;
    [array[currentIndex], array[randomIndex]] = [array[randomIndex], array[currentIndex]];
  }

  return array;
}

interface ValuesSortingActivityProps {
    params: Promise<{ id: string }>;
    isPreview?: boolean;
    onComplete?: () => void;
}


const ValuesSortingActivity: FC<ValuesSortingActivityProps> = ({ params, onComplete }) => {
  const { id: activityId } = use(params);
  const [activity, setActivity] = useState<Activity | null>(null);
  const [valuesState, setValuesState] = useState<ValuesState | null>(null);
  const [draggedValue, setDraggedValue] = useState<any>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalContent, setModalContent] = useState({ title: '', description: '' });

  useEffect(() => {
    const savedActivities = localStorage.getItem('adminActivities');
    if (savedActivities) {
        const activities: Activity[] = JSON.parse(savedActivities);
        const currentActivity = activities.find(a => a.id === activityId);
        if (currentActivity && currentActivity.content) {
            setActivity(currentActivity);
            const initialValues: ValueItem[] = Object.keys(currentActivity.content.values).map((value, index) => ({
                id: `${index + 1}`,
                text: value,
            }));

            const initialState: ValuesState = {
                unassigned: shuffle(initialValues),
            };
            (currentActivity.content.categories || []).forEach((cat: string) => {
                initialState[cat] = [];
            });
            setValuesState(initialState);
        }
    }
  }, [activityId]);


  const handleDragStart = (e: React.DragEvent<HTMLDivElement>, value: any, source: string) => {
    setDraggedValue({ ...value, source });
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>, target: string) => {
    e.preventDefault();
    if (!draggedValue || !valuesState) return;

    const { id, source } = draggedValue;
    if (source === target) return;

    const newValues = JSON.parse(JSON.stringify(valuesState));
    const valueIndex = newValues[source].findIndex((v: any) => v.id === id);
    const [valueToMove] = newValues[source].splice(valueIndex, 1);
    
    newValues[target].push(valueToMove);
    
    setValuesState(newValues);
    setDraggedValue(null);
  };

  const checkSorting = () => {
    if (!valuesState || !activity || !activity.content) return;

    if (valuesState.unassigned.length > 0) {
      setModalContent({ title: 'Keep Going!', description: 'Please sort all the values into the categories.' });
      setIsModalOpen(true);
      return;
    }
    
    let correct = true;
    const correctMapping = activity.content.values;

    for (const category of (activity.content.categories || [])) {
        for (const value of valuesState[category]) {
            if (correctMapping[value.text] !== category) {
                correct = false;
                break;
            }
        }
        if (!correct) break;
    }
    
    if (correct) {
        setModalContent({ title: 'Excellent Work!', description: 'You correctly sorted all the values. You earned 50 character points!' });
        if(onComplete) onComplete();
    } else {
        setModalContent({ title: 'Not Quite!', description: 'Some values are in the wrong category. Think carefully and try again!' });
    }
    setIsModalOpen(true);
  };

  if (!activity || !valuesState) {
    return <div>Loading activity...</div>
  }

  return (
    <div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {(activity.content?.categories || []).map((category: string) => (
              <div key={category} className="p-4 bg-secondary rounded-lg" onDragOver={handleDragOver} onDrop={(e) => handleDrop(e, category)}>
                <h3 className="font-bold text-lg text-center capitalize mb-4">{category}</h3>
                <div className="min-h-[200px] space-y-2 bg-background/50 p-2 rounded-md">
                  {valuesState[category].map((v: any) => (
                    <div key={v.id} draggable onDragStart={(e) => handleDragStart(e, v, category)} className="p-3 bg-card rounded-lg shadow-sm cursor-move text-center font-medium">{v.text}</div>
                  ))}
                </div>
              </div>
            ))}
        </div>

        <div className="mt-6 p-4 border-dashed border-2 rounded-lg" onDragOver={handleDragOver} onDrop={(e) => handleDrop(e, 'unassigned')}>
            <h3 className="font-bold text-center mb-4">Unsorted Values</h3>
            <div className="flex flex-wrap gap-4 justify-center min-h-[60px]">
              {valuesState.unassigned.map((v: any) => (
                <div key={v.id} draggable onDragStart={(e) => handleDragStart(e, v, 'unassigned')} className="p-3 bg-card rounded-lg shadow-sm cursor-move font-medium">{v.text}</div>
              ))}
            </div>
        </div>

        <Button onClick={checkSorting} className="w-full mt-6">
            <CheckCircle className="mr-2 h-4 w-4" />
            Check My Answers
        </Button>
       <AlertDialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="text-center text-2xl">{modalContent.title}</AlertDialogTitle>
            <AlertDialogDescription className="text-center text-lg">
              {modalContent.description}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction onClick={() => setIsModalOpen(false)}>Continue</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default ValuesSortingActivity;
