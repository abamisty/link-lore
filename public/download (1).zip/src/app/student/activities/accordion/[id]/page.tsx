
'use client';

import { useState, useEffect, use } from 'react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import type { Activity } from '@/app/admin/activities/page';

type AccordionItemData = {
    id: string;
    title: string;
    content: string;
};

interface AccordionPlayerProps {
    params: Promise<{ id: string }>;
    isPreview?: boolean;
    onComplete?: () => void;
}

export default function AccordionPlayer({ params }: AccordionPlayerProps) {
    const { id: activityId } = use(params);
    const [activity, setActivity] = useState<Activity | null>(null);

    useEffect(() => {
        const savedActivities = localStorage.getItem('adminActivities');
        if (savedActivities) {
            const activities: Activity[] = JSON.parse(savedActivities);
            const currentActivity = activities.find(a => a.id === activityId);
            if (currentActivity) {
                setActivity(currentActivity);
            }
        }
    }, [activityId]);

    if (!activity) {
        return <div>Loading...</div>;
    }

    const { items = [] } = activity.content || {};

    return (
        <Accordion type="single" collapsible className="w-full">
            {(items as AccordionItemData[]).map(item => (
                <AccordionItem value={item.id} key={item.id}>
                    <AccordionTrigger>{item.title}</AccordionTrigger>
                    <AccordionContent>
                        <div className="whitespace-pre-wrap p-2">{item.content}</div>
                    </AccordionContent>
                </AccordionItem>
            ))}
        </Accordion>
    );
}
