
'use client';

import { useState, useEffect, use } from 'react';
import type { Activity } from '@/app/admin/activities/page';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { RefreshCw } from 'lucide-react';

type Choice = {
    id: string;
    text: string;
    nextSceneId: string | null;
};

type Scene = {
    id: string;
    title: string;
    text: string;
    image: string | null;
    isEnding: boolean;
    choices: Choice[];
};

interface BranchingScenarioPlayerProps {
    params: Promise<{ id: string }>;
    isPreview?: boolean;
    onComplete?: () => void;
}

export default function BranchingScenarioPlayer({ params, onComplete }: BranchingScenarioPlayerProps) {
    const { id: activityId } = use(params);
    const [activity, setActivity] = useState<Activity | null>(null);
    const [scenes, setScenes] = useState<Scene[]>([]);
    const [startSceneId, setStartSceneId] = useState<string | null>(null);
    const [currentScene, setCurrentScene] = useState<Scene | null>(null);
    const [hasCompleted, setHasCompleted] = useState(false);

    useEffect(() => {
        const savedActivities = localStorage.getItem('adminActivities');
        if (savedActivities) {
            const activities: Activity[] = JSON.parse(savedActivities);
            const currentActivity = activities.find(a => a.id === activityId);
            if (currentActivity) {
                setActivity(currentActivity);
                const content = currentActivity.content || {};
                setScenes(content.scenes || []);
                setStartSceneId(content.startSceneId || null);
                if (content.startSceneId) {
                    setCurrentScene(content.scenes.find((s: Scene) => s.id === content.startSceneId) || null);
                }
            }
        }
    }, [activityId]);

    const handleChoiceClick = (nextSceneId: string | null) => {
        if (!nextSceneId) return;
        
        const nextScene = scenes.find(s => s.id === nextSceneId);
        if (nextScene) {
            setCurrentScene(nextScene);
            if (nextScene.isEnding && onComplete) {
                onComplete();
                setHasCompleted(true);
            }
        }
    };

    const handleRestart = () => {
        if (startSceneId) {
            setCurrentScene(scenes.find(s => s.id === startSceneId) || null);
            setHasCompleted(false);
        }
    };

    if (!activity || !currentScene) {
        return <div>Loading scenario...</div>;
    }

    return (
        <div className="w-full max-w-3xl mx-auto">
            <Card>
                <CardContent className="p-6">
                    {currentScene.image && (
                        <div className="mb-4">
                             <Image src={currentScene.image} alt={currentScene.title} width={600} height={338} className="rounded-lg object-cover w-full aspect-video" />
                        </div>
                    )}
                    <h2 className="text-2xl font-bold mb-2">{currentScene.title}</h2>
                    <p className="text-muted-foreground whitespace-pre-wrap">{currentScene.text}</p>
                    
                    <div className="mt-6 space-y-3">
                        {!currentScene.isEnding ? (
                            currentScene.choices.map(choice => (
                                <Button 
                                    key={choice.id} 
                                    onClick={() => handleChoiceClick(choice.nextSceneId)} 
                                    className="w-full justify-start text-left h-auto py-3"
                                    variant="outline"
                                >
                                    {choice.text}
                                </Button>
                            ))
                        ) : (
                            <div className="text-center p-4 bg-secondary rounded-md">
                                <h3 className="font-bold text-lg">The End</h3>
                                {hasCompleted && <p className="text-sm text-muted-foreground">You have completed the scenario!</p>}
                                <Button onClick={handleRestart} className="mt-4">
                                    <RefreshCw className="mr-2 h-4 w-4" />
                                    Play Again
                                </Button>
                            </div>
                        )}
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}

    