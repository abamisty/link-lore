'use client';

import { useActionState } from 'react';
import { useFormStatus } from 'react-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { createCustomCourseRequestAction, type CustomCourseRequestState } from '@/app/actions/custom-course-request';
import { useToast } from "@/hooks/use-toast";
import React, { useEffect } from 'react';
import { Loader2, Send } from 'lucide-react';

const initialState: CustomCourseRequestState = {
    success: false,
    error: null,
};

function SubmitButton() {
    const { pending } = useFormStatus();

    return (
        <Button type="submit" className="w-full" disabled={pending}>
            {pending ? (
                <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Submitting Request...
                </>
            ) : (
                <>
                    <Send className="mr-2 h-4 w-4" />
                    Submit Request
                </>
            )}
        </Button>
    );
}

export default function CustomCourseRequestPage() {
    const [state, formAction] = useActionState(createCustomCourseRequestAction, initialState);
    const { toast } = useToast();

    useEffect(() => {
        if (state.error) {
            toast({
                title: 'Error',
                description: state.error,
                variant: 'destructive',
            });
        }
        if (state.success) {
            toast({
                title: 'Success!',
                description: 'Your custom course request has been submitted to the administrators.',
            });
        }
    }, [state, toast]);


    return (
        <div className="grid gap-4 md:gap-8">
            <Card className="max-w-2xl mx-auto">
                <form action={formAction}>
                    <CardHeader>
                        <CardTitle>Request a Custom Course</CardTitle>
                        <CardDescription>
                            Fill out the form below to request a course tailored to your child's needs and your family's values.
                            An administrator will review your request.
                        </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                        <div className="space-y-2">
                            <Label htmlFor="childName">Child's Name</Label>
                            <Select name="childName" required>
                                <SelectTrigger id="childName">
                                    <SelectValue placeholder="Select your child" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="Alex">Alex</SelectItem>
                                    <SelectItem value="Benny">Benny</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="courseTopic">Course Topic</Label>
                            <Input id="courseTopic" name="courseTopic" placeholder="e.g., Financial Responsibility, Digital Citizenship" required />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="familyValues">Key Family Values</Label>
                            <Textarea
                                id="familyValues"
                                name="familyValues"
                                placeholder="Describe the core values you want this course to emphasize (e.g., Honesty, Compassion, Hard Work)."
                                required
                                rows={4}
                            />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="learningGoals">Learning Goals</Label>
                            <Textarea
                                id="learningGoals"
                                name="learningGoals"
                                placeholder="What specific skills or knowledge do you want your child to gain? (e.g., Learn to create a budget, understand online safety)."
                                required
                                rows={4}
                            />
                        </div>
                    </CardContent>
                    <CardFooter>
                        <SubmitButton />
                    </CardFooter>
                </form>
            </Card>
        </div>
    );
}
