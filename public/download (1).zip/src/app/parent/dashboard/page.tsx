'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { CheckCircle, BookOpen } from "lucide-react";
import { ChartContainer, ChartTooltip, ChartTooltipContent, ChartConfig } from '@/components/ui/chart';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer } from 'recharts';
import { DiscussionGenerator } from "@/components/ai/discussion-generator";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { AddChildDialog } from "@/components/parent/add-child-dialog";
import { useToast } from "@/hooks/use-toast";

const chartData = [
  { trait: 'Empathy', progress: 75, fill: "var(--color-empathy)" },
  { trait: 'Resilience', progress: 40, fill: "var(--color-resilience)" },
  { trait: 'Kindness', progress: 90, fill: "var(--color-kindness)" },
  { trait: 'Integrity', progress: 60, fill: "var(--color-integrity)" },
  { trait: 'Gratitude', progress: 80, fill: "var(--color-gratitude)" },
];

const chartConfig = {
  progress: {
    label: "Progress",
  },
  empathy: {
    label: "Empathy",
    color: "hsl(var(--chart-1))",
  },
  resilience: {
    label: "Resilience",
    color: "hsl(var(--chart-2))",
  },
  kindness: {
    label: "Kindness",
    color: "hsl(var(--chart-3))",
  },
  integrity: {
    label: "Integrity",
    color: "hsl(var(--chart-4))",
  },
  gratitude: {
    label: "Gratitude",
    color: "hsl(var(--chart-5))",
  },
} satisfies ChartConfig;

const recentActivities = [
  { type: "lesson", title: "Completed 'The Art of Kindness'", description: "Unit 5, Lesson 2", icon: <CheckCircle className="h-5 w-5 text-green-500" /> },
  { type: "course", title: "Started 'Developing Resilience'", description: "Began Unit 1", icon: <BookOpen className="h-5 w-5 text-primary" /> },
  { type: "lesson", title: "Completed 'Understanding Others'", description: "Unit 4, Lesson 1", icon: <CheckCircle className="h-5 w-5 text-green-500" /> },
];

export default function ParentDashboardPage() {
  const { toast } = useToast();

  const handleChildAdded = (newChild: { name: string }) => {
     toast({
        title: 'Success!',
        description: `${newChild.name} has been added to your family. You can manage them in the 'My Children' section.`,
    });
  };
    
  return (
    <div className="grid gap-4 md:gap-8">
      <Card>
        <CardHeader className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
                <Avatar className="h-16 w-16">
                    <AvatarImage src="https://placehold.co/100x100.png?text=A" alt="Alex" />
                    <AvatarFallback>A</AvatarFallback>
                </Avatar>
                <div>
                    <CardTitle className="text-2xl">Alex&apos;s Dashboard</CardTitle>
                    <CardDescription>Here is an overview of Alex&apos;s progress and activities.</CardDescription>
                </div>
            </div>
            <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
                <Button asChild variant="outline">
                    <Link href="/courses">
                        <BookOpen />
                        View Course Library
                    </Link>
                </Button>
                <AddChildDialog onChildAdded={handleChildAdded} />
            </div>
        </CardHeader>
      </Card>
      
      <div className="grid gap-4 lg:grid-cols-5 lg:gap-8">
        <div className="lg:col-span-3 space-y-4 lg:space-y-8">
            <Card>
              <CardHeader>
                <CardTitle>Progress Summary</CardTitle>
                <CardDescription>Character trait development</CardDescription>
              </CardHeader>
              <CardContent>
                <ChartContainer config={chartConfig} className="h-[250px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={chartData} margin={{ top: 0, right: 0, left: -10, bottom: 0 }}>
                            <CartesianGrid vertical={false} />
                            <XAxis dataKey="trait" tickLine={false} axisLine={false} tickMargin={8} fontSize={12} />
                            <YAxis tickLine={false} axisLine={false} tickMargin={8} />
                            <ChartTooltip cursor={false} content={<ChartTooltipContent indicator="dot" />} />
                            <Bar dataKey="progress" radius={4} />
                        </BarChart>
                    </ResponsiveContainer>
                </ChartContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
                <CardDescription>Alex&apos;s latest achievements and course interactions.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentActivities.map((activity, i) => (
                    <div key={i} className="flex items-center gap-4">
                      <div className="bg-secondary p-2 rounded-full">{activity.icon}</div>
                      <div>
                        <p className="font-medium">{activity.title}</p>
                        <p className="text-sm text-muted-foreground">{activity.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
        </div>
        <div className="lg:col-span-2">
            <DiscussionGenerator />
        </div>
      </div>
    </div>
  );
}
