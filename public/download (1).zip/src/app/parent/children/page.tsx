'use client';

import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Award, BookOpen } from "lucide-react";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { AddChildDialog } from "@/components/parent/add-child-dialog";

const initialChildrenData = [
    {
        name: "Alex",
        avatar: "https://placehold.co/100x100.png?text=A",
        coursesInProgress: 3,
        totalPoints: 980,
    },
    {
        name: "Benny",
        avatar: "https://placehold.co/100x100.png?text=B",
        coursesInProgress: 2,
        totalPoints: 750,
    }
];

export default function MyChildrenPage() {
  const [childrenData, setChildrenData] = useState(initialChildrenData);

  const handleChildAdded = (newChild: { name: string; email: string }) => {
    const newChildData = {
        name: newChild.name,
        avatar: `https://placehold.co/100x100.png?text=${newChild.name.charAt(0)}`,
        coursesInProgress: 0,
        totalPoints: 0,
    };
    setChildrenData(prevData => [...prevData, newChildData]);
  };

  return (
    <div className="grid gap-4 md:gap-8">
      <div className="flex items-center justify-between">
        <div>
            <h1 className="text-2xl font-bold">Manage My Children</h1>
            <p className="text-muted-foreground">
                View your children's progress or add a new child to your family.
            </p>
        </div>
        <AddChildDialog onChildAdded={handleChildAdded} />
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {childrenData.map((child) => (
            <Card key={child.name}>
                <CardHeader className="flex flex-row items-center gap-4">
                     <Avatar className="h-16 w-16">
                        <AvatarImage src={child.avatar} alt={child.name} />
                        <AvatarFallback>{child.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                        <CardTitle className="text-2xl">{child.name}</CardTitle>
                        <CardDescription>Student Account</CardDescription>
                    </div>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="flex justify-between items-center p-3 bg-secondary rounded-md">
                        <div className="flex items-center gap-2">
                            <BookOpen className="h-5 w-5 text-primary" />
                            <span className="text-sm font-medium">Courses in Progress</span>
                        </div>
                        <span className="text-lg font-bold">{child.coursesInProgress}</span>
                    </div>
                     <div className="flex justify-between items-center p-3 bg-secondary rounded-md">
                        <div className="flex items-center gap-2">
                            <Award className="h-5 w-5 text-primary" />
                            <span className="text-sm font-medium">Total Character Points</span>
                        </div>
                        <span className="text-lg font-bold">{child.totalPoints}</span>
                    </div>
                </CardContent>
                <CardContent>
                     <Button asChild className="w-full">
                        <Link href="/student/dashboard">View Dashboard</Link>
                    </Button>
                </CardContent>
            </Card>
        ))}
      </div>
    </div>
  );
}
