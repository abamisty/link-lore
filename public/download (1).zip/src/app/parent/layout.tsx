
'use client';

import { DashboardLayout } from "@/components/dashboard/sidebar";
import React, { useEffect } from 'react';

export default function ParentLayout({ children }: { children: React.ReactNode }) {
    
    useEffect(() => {
        // In a real app, you'd get this from an auth context.
        // We'll use localStorage for this demo to persist the role.
        if (typeof window !== 'undefined') {
            localStorage.setItem('userRole', 'parent');
        }
    }, []);

    return <DashboardLayout role="parent">{children}</DashboardLayout>;
}
