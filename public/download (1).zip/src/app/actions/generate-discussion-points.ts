'use server';

import {
  generateFamilyDiscussionPoints,
  GenerateFamilyDiscussionPointsInput,
} from '@/ai/flows/generate-family-discussion-points';
import { z } from 'zod';

const formSchema = z.object({
  lessonSummary: z.string().min(10, 'Please provide a more detailed lesson summary.'),
  keyAreas: z.string().min(10, 'Please provide more detail on key areas.'),
  familyValues: z.string().min(5, 'Please list at least one family value.'),
});

type State = {
  discussionPoints?: string;
  error?: string | null;
};

export async function generateDiscussionPointsAction(
  prevState: State,
  formData: FormData
): Promise<State> {
  const validatedFields = formSchema.safeParse({
    lessonSummary: formData.get('lessonSummary'),
    keyAreas: formData.get('keyAreas'),
    familyValues: formData.get('familyValues'),
  });

  if (!validatedFields.success) {
    return {
      error: validatedFields.error.flatten().fieldErrors.lessonSummary?.[0] ||
             validatedFields.error.flatten().fieldErrors.keyAreas?.[0] ||
             validatedFields.error.flatten().fieldErrors.familyValues?.[0] ||
             'Invalid input.',
    };
  }
  
  try {
    const input: GenerateFamilyDiscussionPointsInput = validatedFields.data;
    const result = await generateFamilyDiscussionPoints(input);
    return { discussionPoints: result.discussionPoints, error: null };
  } catch (error) {
    console.error(error);
    return { error: 'Failed to generate discussion points. Please try again.' };
  }
}
