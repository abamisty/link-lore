'use server';

import { redirect } from 'next/navigation';
import { z } from 'zod';

const emailSchema = z.string().email({ message: 'Invalid email address.' });
const passwordSchema =
  z.string().min(6, { message: 'Password must be at least 6 characters.' });

const loginSchema = z.object({
  email: emailSchema,
  password: passwordSchema,
});

const signupSchema = z.object({
  fullName: z.string().min(2, { message: 'Full name is required.' }),
  email: emailSchema,
  password: passwordSchema,
  role: z.enum(['student', 'parent', 'admin'], {
    message: 'Please select a role.',
  }),
});

export type LoginState = {
  error?: string;
  success?: boolean;
};

export type SignupState = {
  error?: string;
  success?: boolean;
  message?: string;
};

export async function loginAction(
  prevState: LoginState,
  formData: FormData
): Promise<LoginState> {
  const validatedFields = loginSchema.safeParse(
    Object.fromEntries(formData.entries())
  );

  if (!validatedFields.success) {
    return {
      error:
        validatedFields.error.flatten().fieldErrors.email?.[0] ||
        validatedFields.error.flatten().fieldErrors.password?.[0] ||
        'Invalid credentials.',
    };
  }
  
  const { email } = validatedFields.data;

  // This is a mock authentication. In a real app, you'd verify credentials.
  // We'll redirect based on a mock role determined by the email.
  let redirectTo = '/login';
  if (email.includes('student')) {
    redirectTo = '/student/dashboard';
  } else if (email.includes('parent')) {
    redirectTo = '/parent/dashboard';
  } else if (email.includes('admin')) {
    redirectTo = '/admin/dashboard';
  } else {
    // Default for generic emails like test@example.com
    redirectTo = '/student/dashboard';
  }

  redirect(redirectTo);
}

export async function signupAction(
  prevState: SignupState,
  formData: FormData
): Promise<SignupState> {
  const validatedFields = signupSchema.safeParse(
    Object.fromEntries(formData.entries())
  );

  if (!validatedFields.success) {
    return {
      error:
        validatedFields.error.flatten().fieldErrors.fullName?.[0] ||
        validatedFields.error.flatten().fieldErrors.email?.[0] ||
        validatedFields.error.flatten().fieldErrors.password?.[0] ||
        validatedFields.error.flatten().fieldErrors.role?.[0] ||
        'Invalid input.',
    };
  }

  // In a real app, you would create the user in your database here.
  // For this demo, we'll just simulate a successful sign-up.
  console.log('New user signed up:', validatedFields.data);

  return {
    success: true,
    message: 'Sign-up successful! You can now log in with your credentials.',
  };
}
