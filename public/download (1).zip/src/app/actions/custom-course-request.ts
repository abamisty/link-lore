'use server';

import { z } from 'zod';

const customCourseRequestSchema = z.object({
  childName: z.string().min(1, { message: "Please select a child." }),
  courseTopic: z.string().min(3, { message: "Please provide a course topic." }),
  familyValues: z.string().min(10, { message: "Please describe your family values." }),
  learningGoals: z.string().min(10, { message: "Please describe the learning goals." }),
});

export type CustomCourseRequestState = {
  success: boolean;
  error?: string | null;
};

export async function createCustomCourseRequestAction(
  prevState: CustomCourseRequestState,
  formData: FormData
): Promise<CustomCourseRequestState> {
  const validatedFields = customCourseRequestSchema.safeParse(Object.fromEntries(formData.entries()));

  if (!validatedFields.success) {
    const errors = validatedFields.error.flatten().fieldErrors;
    return {
      success: false,
      error: errors.childName?.[0] ||
             errors.courseTopic?.[0] ||
             errors.familyValues?.[0] ||
             errors.learningGoals?.[0] ||
             "Invalid input. Please check the form.",
    };
  }

  // In a real application, you would save this request to a database
  // for an administrator to review.
  console.log("New Custom Course Request:", validatedFields.data);

  // For this demo, we'll just simulate a successful submission.
  await new Promise(resolve => setTimeout(resolve, 1000));

  return { success: true, error: null };
}
