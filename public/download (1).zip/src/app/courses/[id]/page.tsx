
'use client';

import Link from 'next/link';
import { Header } from '@/components/header';
import { Footer } from '@/components/footer';
import { Card, CardContent } from '@/components/ui/card';
import { Brain, Gamepad2 } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import React, { useEffect, useState, use } from 'react';
import { Button } from '@/components/ui/button';
import { EnrollChildDialog } from '@/components/parent/enroll-child-dialog';
import { type Course as AdminCourse } from '@/app/admin/courses/page';

const getStatusStyles = (status: string) => {
    switch (status) {
        case 'completed':
            return {
                node: 'bg-gradient-to-br from-green-400 to-green-600',
                ring: 'ring-green-200',
            };
        case 'current':
            return {
                node: 'bg-gradient-to-br from-blue-400 to-blue-600',
                ring: 'ring-blue-300 ring-4',
            };
        case 'locked':
        default:
             return {
                node: `bg-gray-300`,
                ring: 'ring-gray-200',
             };
    }
};

const LessonNode = ({ lesson, courseId }: { lesson: any, courseId: string }) => {
    const styles = getStatusStyles(lesson.status);
    const isEmoji = lesson.icon && !/^[a-zA-Z✓]*$/.test(lesson.icon);
    const lessonUrl = `/courses/${courseId}/${lesson.id}`;

    const NodeContent = () => (
        <div className={`relative w-20 h-20 md:w-24 md:h-24 flex items-center justify-center rounded-full ${styles.node} shadow-lg border-4 border-white ${styles.ring} transition-transform transform group-hover:scale-110`}>
            <span className={`font-bold ${isEmoji ? 'text-3xl md:text-4xl' : 'text-2xl md:text-3xl'}`}>{lesson.status === 'locked' ? '🔒' : lesson.icon || '📝'}</span>
        </div>
    );

    return (
        <div className="flex flex-col items-center gap-2 flex-shrink-0 group">
            {lesson.status !== 'locked' ? (
                <Link href={lessonUrl}>
                    <NodeContent />
                </Link>
            ) : (
                <div className="cursor-not-allowed">
                    <NodeContent />
                </div>
            )}
            <p className="text-center text-xs md:text-sm font-medium w-24 md:w-28 truncate group-hover:whitespace-normal group-hover:text-clip">{lesson.title}</p>
        </div>
    );
};

export default function CourseDetailPage({ params }: { params: Promise<{ id: string }> }) {
    const { id: courseId } = use(params);
    const [course, setCourse] = useState<any | null>(null);
    const [isParent, setIsParent] = React.useState(false);
    const [loading, setLoading] = useState(true);

     useEffect(() => {
        if (typeof window !== 'undefined') {
            setLoading(true);
            const role = localStorage.getItem('userRole');
            setIsParent(role === 'parent');
            
            const allCoursesStr = localStorage.getItem('adminCourses');
            const allCourses: AdminCourse[] = allCoursesStr ? JSON.parse(allCoursesStr) : [];
            const baseCourseData = allCourses.find(c => c.id === courseId);

            if (!baseCourseData) {
                 setLoading(false);
                 return;
            }

            let courseData: any = {
                ...baseCourseData,
                progress: 0,
                icon: Brain,
                isEnrolled: true,
                units: [],
            };
            
            const savedStructureStr = localStorage.getItem(`course-structure-${courseId}`);
            if (savedStructureStr) {
                const savedStructure = JSON.parse(savedStructureStr);

                if ((savedStructure.units || []).length > 0) {
                   courseData.units = (savedStructure.units || []).map((savedUnit: any, unitIndex: number) => {
                       const newLessons = (savedUnit.lessons || []).map((l: any, lessonIndex: number) => ({
                           ...l, 
                           status: (unitIndex === 0 && lessonIndex === 0) ? 'current' : 'locked',
                           icon: l.activityId ? <Gamepad2 /> : '📝'
                       }));
                       
                       return { 
                           ...savedUnit,
                           lessons: newLessons,
                        };
                   });
                }
            }
            
            const savedProgress = localStorage.getItem(`course-progress-${courseId}`);
            if (savedProgress) {
                courseData.progress = JSON.parse(savedProgress).progress;
            }
            
            setCourse(courseData);
            setLoading(false);
        }
    }, [courseId]);


    useEffect(() => {
        if (!course) return;

        const handleFocus = () => {
             if (typeof window !== 'undefined' && course) {
                const lessonId = localStorage.getItem('lastCompletedLesson');
                if (lessonId) {
                    const newCourseData = JSON.parse(JSON.stringify(course)); 
                    let lessonFound = false;
                    for (const unit of newCourseData.units) {
                        for (let i = 0; i < (unit.lessons || []).length; i++) {
                            const lesson = unit.lessons[i];
                             if (String(lesson.id) === lessonId && lesson.status !== 'completed') {
                                lesson.status = 'completed';
                                if (i + 1 < unit.lessons.length) {
                                    unit.lessons[i+1].status = 'current';
                                } else {
                                    const currentUnitIndex = newCourseData.units.findIndex((u: any) => u.id === unit.id);
                                    if (currentUnitIndex + 1 < newCourseData.units.length) {
                                        const nextUnit = newCourseData.units[currentUnitIndex + 1];
                                        if ((nextUnit.lessons || []).length > 0) {
                                            nextUnit.lessons[0].status = 'current';
                                        }
                                    }
                                }
                                lessonFound = true;
                                break;
                            }
                        }
                        if (lessonFound) break;
                    }

                    if (lessonFound) {
                        const allLessons = newCourseData.units.flatMap((u:any) => u.lessons || []);
                        const completedLessons = allLessons.filter((l:any) => l.status === 'completed').length;
                        newCourseData.progress = allLessons.length > 0 ? Math.round((completedLessons / allLessons.length) * 100) : 0;

                        setCourse(newCourseData);
                        localStorage.setItem(`course-progress-${courseId}`, JSON.stringify({ progress: newCourseData.progress }));
                        localStorage.removeItem('lastCompletedLesson');
                    }
                }
            }
        };

        window.addEventListener('focus', handleFocus);
        handleFocus();

        return () => {
            window.removeEventListener('focus', handleFocus);
        };
    }, [course, courseId]);


    if (loading) {
        return (
            <div className="flex min-h-screen flex-col bg-slate-50">
                <Header />
                <main className="flex-1 flex items-center justify-center">
                    <div>Loading course...</div>
                </main>
                <Footer />
            </div>
        );
    }
    
    if (!course) {
        return (
            <div className="flex min-h-screen flex-col bg-slate-50">
                <Header />
                <main className="flex-1 flex items-center justify-center">
                    <div>Course not found.</div>
                </main>
                <Footer />
            </div>
        );
    }

    const CourseIcon = course.icon || Brain;
    
    return (
        <div className="flex min-h-screen flex-col bg-slate-50">
            <Header />
            <main className="flex-1">
                <section className="w-full py-8 md:py-12">
                    <div className="container mx-auto px-4 md:px-6">
                        <div className="bg-white/70 backdrop-blur-sm rounded-xl p-4 md:p-8 shadow-sm border border-gray-100">
                             {/* Course Header */}
                            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6 md:mb-8">
                                <div className="flex items-center gap-4">
                                    <div className="w-12 h-12 md:w-16 md:h-16 bg-gradient-to-br from-primary to-accent rounded-xl flex items-center justify-center">
                                        <CourseIcon className="w-6 h-6 md:w-8 md:h-8 text-white" />
                                    </div>
                                    <div>
                                        <h1 className="text-2xl md:text-4xl font-bold text-gray-800">{course.title}</h1>
                                        
                                    </div>
                                </div>
                                <div className="flex items-center gap-3 w-full sm:w-auto">
                                     {isParent && <EnrollChildDialog courseTitle={course.title} />}
                                    <div className="flex items-center gap-3 w-full sm:w-auto sm:max-w-xs">
                                        <span className="text-sm font-medium text-gray-600 whitespace-nowrap">Progress:</span>
                                        <Progress value={course.progress} className="w-full h-3" />
                                        <span className="text-sm font-bold text-gray-800">{course.progress}%</span>
                                    </div>
                                </div>
                            </div>
                            
                            {/* Units */}
                            <div className="space-y-10 md:space-y-12">
                                {(course.units || []).map((unit: any, unitIndex: number) => (
                                    <div key={unit.id}>
                                        {/* Unit Header */}
                                        <div className="flex items-center gap-3 mb-6 md:mb-8">
                                            <div className="w-8 h-8 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center text-white font-bold text-sm">
                                                {unitIndex + 1}
                                            </div>
                                            <h2 className="text-xl md:text-2xl font-bold text-gray-700">Unit {unitIndex + 1}: {unit.title}</h2>
                                        </div>

                                        {/* Learning Path */}
                                        {(unit.lessons || []).length > 0 ? (
                                        <div className="relative mb-8 overflow-x-auto pb-4 -ml-4 pl-4">
                                            <div className="absolute top-1/2 left-0 w-full h-1 -translate-y-1/2 hidden md:block">
                                                 <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" className="overflow-visible">
                                                    <path d="M0 0 C 150 40, 250 -40, 400 0 S 650 40, 800 0" stroke="#d1d5db" strokeWidth="3" fill="none" strokeDasharray="6 6" transform="scale(1.2 1) translate(0 1)"/>
                                                </svg>
                                            </div>
                                            <div className="relative flex justify-start md:justify-between items-start gap-4 md:px-8">
                                                {(unit.lessons || []).map((lesson: any, index: number) => (
                                                    <React.Fragment key={lesson.id}>
                                                        <LessonNode lesson={lesson} courseId={course.id} />
                                                        {index < unit.lessons.length - 1 && <div className="md:hidden self-center border-t-4 border-dashed border-gray-300 w-8 mt-[-24px]" />}
                                                    </React.Fragment>
                                                ))}
                                            </div>
                                        </div>
                                        ) : (
                                            <div className="text-center py-8 text-gray-500">
                                                <p>No lessons in this unit yet. The administrator is working on it!</p>
                                            </div>
                                        )}
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </section>
            </main>
            <Footer />
        </div>
    );
}
