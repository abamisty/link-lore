
'use client';

import type { FC } from 'react';
import React, { useState, useEffect, use } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft, Lightbulb } from 'lucide-react';
import Link from 'next/link';
import type { Activity } from '@/app/admin/activities/page';
import { type Course as AdminCourse } from '@/app/admin/courses/page';

// Dynamically import all activity players
import AccordionPlayer from '@/app/student/activities/accordion/[id]/page';
import DragTheWordsPlayer from '@/app/student/activities/drag-the-words/[id]/page';
import FillInTheBlanksPlayer from '@/app/student/activities/fill-in-the-blanks/[id]/page';
import InteractiveDialoguePlayer from '@/app/student/activities/interactive-dialogue/[id]/page';
import MultipleChoicePlayer from '@/app/student/activities/multiple-choice/[id]/page';
import QuestionSetPlayer from '@/app/student/activities/question-set/[id]/page';
import ScenarioPlayer from '@/app/student/activities/scenario/[id]/page';
import ValuesSortingPlayer from '@/app/student/activities/values-sorting/[id]/page';
import BranchingScenarioPlayer from '@/app/student/activities/branching-scenario/[id]/page';
import { Button } from '@/components/ui/button';

interface LessonPageProps {
  params: Promise<{ id: string; lessonId: string }>;
}

type Lesson = {
    id: string;
    title: string;
    activityId?: string;
}

const LessonPage: FC<LessonPageProps> = ({ params }) => {
    const { id: courseId, lessonId } = use(params);
    const [course, setCourse] = useState<AdminCourse | null>(null);
    const [lesson, setLesson] = useState<Lesson | null>(null);
    const [activity, setActivity] = useState<Activity | null>(null);
    const [loading, setLoading] = useState(true);
    const [isComplete, setIsComplete] = useState(false);

    useEffect(() => {
        if (typeof window !== 'undefined') {
            setLoading(true);
            
            let courseStructureStr: string | null = null;
            
            if (courseId === 'preview-course') {
                const previewCourseStr = localStorage.getItem(`course-structure-${courseId}`);
                if (previewCourseStr) {
                    const previewCourse = JSON.parse(previewCourseStr);
                    setCourse(previewCourse);
                    courseStructureStr = previewCourseStr;
                }
            } else {
                const allCoursesStr = localStorage.getItem('adminCourses');
                const allCourses: AdminCourse[] = allCoursesStr ? JSON.parse(allCoursesStr) : [];
                const currentCourse = allCourses.find(c => c.id === courseId);
                setCourse(currentCourse || null);
                courseStructureStr = localStorage.getItem(`course-structure-${courseId}`);
            }

            if (courseStructureStr) {
                const courseStructure = JSON.parse(courseStructureStr);
                for (const unit of (courseStructure.units || [])) {
                    const foundLesson = (unit.lessons || []).find((l: any) => String(l.id) === lessonId);
                    if (foundLesson) {
                        setLesson(foundLesson);
                        
                        if(foundLesson.activityId) {
                            const allActivitiesStr = localStorage.getItem('adminActivities');
                            const allActivities: Activity[] = allActivitiesStr ? JSON.parse(allActivitiesStr) : [];
                            const foundActivity = allActivities.find(a => a.id === foundLesson.activityId);
                            setActivity(foundActivity || null);
                        }
                        break;
                    }
                }
            }
            setLoading(false);
        }
    }, [courseId, lessonId]);


    const handleComplete = () => {
        if (typeof window !== 'undefined') {
            localStorage.setItem('lastCompletedLesson', lessonId);
            setIsComplete(true);
        }
    }

    const renderActivity = () => {
        if (!activity || !lesson?.activityId) return null;
        
        // We create a mock params object because the activity pages expect it
        const activityParams = Promise.resolve({ id: lesson.activityId });

        const activityProps = {
            params: activityParams,
            isPreview: courseId === 'preview-course', // Pass a prop to hide nav if it's a preview
            onComplete: handleComplete
        };

        switch (activity.type) {
            case 'Accordion':
                return <AccordionPlayer {...activityProps} />;
            case 'Drag the Words':
                return <DragTheWordsPlayer {...activityProps} />;
            case 'Fill in the Blanks':
                return <FillInTheBlanksPlayer {...activityProps} />;
            case 'Interactive Dialogue':
                 return <InteractiveDialoguePlayer {...activityProps} />;
            case 'Multiple Choice':
                return <MultipleChoicePlayer {...activityProps} />;
            case 'Question Set':
                return <QuestionSetPlayer {...activityProps} />;
            case 'Scenario':
                return <ScenarioPlayer {...activityProps} />;
            case 'Values Sorting':
                return <ValuesSortingPlayer {...activityProps} />;
            case 'Branching Scenario':
                return <BranchingScenarioPlayer {...activityProps} />;
            default:
                return <p>This activity type ({activity.type}) is not supported yet.</p>;
        }
    };


    if (loading) {
        return (
             <div className="flex min-h-screen flex-col items-center justify-center">
                <div>Loading lesson...</div>
            </div>
        )
    }

    if (!lesson) {
         return (
             <div className="flex min-h-screen flex-col items-center justify-center">
                <div>Lesson not found.</div>
            </div>
        )
    }

  return (
    <div className="flex min-h-screen flex-col">
      <main className="flex-1 py-12 md:py-16">
        <div className="container mx-auto px-4 md:px-6">
          
          <div className="mb-8">
             {courseId !== 'preview-course' && (
                <Link href={`/courses/${courseId}`} className="inline-flex items-center text-sm font-medium text-muted-foreground hover:text-primary mb-4">
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Back to Course
                </Link>
             )}
            <h1 className="text-4xl font-bold text-gray-800">{lesson.title}</h1>
            {course && <p className="text-lg text-muted-foreground mt-2">from: {course.title}</p>}
          </div>
          
           <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Lightbulb className="text-primary"/>
                    <span>Lesson Content</span>
                  </CardTitle>
                   <CardDescription>
                       {activity ? activity.instructions || "Complete the activity below to finish the lesson." : "The content for this lesson is being developed."}
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    {activity ? (
                       renderActivity()
                    ) : (
                         <div className="text-center py-12">
                            <h3 className="text-xl font-semibold">Content Coming Soon!</h3>
                            <p>Check back later for this lesson's content.</p>
                        </div>
                    )}
                </CardContent>
                 {activity && courseId !== 'preview-course' && (
                    <CardContent>
                         <Button onClick={handleComplete} disabled={isComplete} className="w-full">
                            {isComplete ? 'Lesson Complete!' : 'Mark as Complete'}
                        </Button>
                    </CardContent>
                )}
              </Card>

        </div>
      </main>
    </div>
  );
}

export default LessonPage;
