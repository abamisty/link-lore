
'use client';

import Link from 'next/link';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Header } from '@/components/header';
import { Footer } from '@/components/footer';
import Image from 'next/image';
import { EnrollChildDialog } from '@/components/parent/enroll-child-dialog';
import React from 'react';
import { type Course as AdminCourse } from '@/app/admin/courses/page';

export default function CoursesPage() {
    const [isParent, setIsParent] = React.useState(false);
    const [courses, setCourses] = React.useState<AdminCourse[]>([]);

    React.useEffect(() => {
        if (typeof window !== 'undefined') {
            const role = localStorage.getItem('userRole');
            setIsParent(role === 'parent');
            
            const savedCourses = localStorage.getItem('adminCourses');
            if (savedCourses) {
                setCourses(JSON.parse(savedCourses));
            }
        }
    }, []);

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1">
        <section className="w-full py-12 md:py-20 lg:py-24">
          <div className="container mx-auto px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl font-headline">
                Our Courses
              </h1>
              <p className="max-w-[700px] text-muted-foreground md:text-xl">
                Explore our catalog of courses designed to build character and empower young minds.
              </p>
            </div>
            <div className="grid gap-6 md:gap-8 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 mt-12">
              {courses.map((course) => (
                <Card key={course.id} className="flex flex-col overflow-hidden transform transition-transform duration-300 hover:scale-105 hover:shadow-xl">
                  <Image
                    alt={course.title}
                    className="aspect-video w-full object-cover"
                    data-ai-hint="child learning education"
                    height={338}
                    src={`https://picsum.photos/seed/${course.id}/600/400`}
                    width={600}
                  />
                  <CardHeader>
                    <div className="flex gap-2 flex-wrap">
                        {course.tags.map(tag => <Badge key={tag} variant="secondary">{tag}</Badge>)}
                    </div>
                    <CardTitle className="mt-2">{course.title}</CardTitle>
                    <CardDescription>{course.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="flex-grow">
                    <p className="text-sm font-medium text-muted-foreground">{course.units} Units</p>
                  </CardContent>
                  <CardFooter className='w-full'>
                    {isParent ? (
                        <EnrollChildDialog courseTitle={course.title} />
                    ) : (
                        <Button asChild className="w-full">
                            <Link href={`/courses/${course.id}`}>View Course</Link>
                        </Button>
                    )}
                  </CardFooter>
                </Card>
              ))}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
