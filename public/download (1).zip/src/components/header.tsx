import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { AppLogo } from '@/components/icons';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Menu } from 'lucide-react';

export function Header() {
  return (
    <header className="px-4 lg:px-6 h-16 flex items-center bg-card shadow-sm sticky top-0 z-40">
      <Link href="/" className="flex items-center justify-center" prefetch={false}>
        <AppLogo className="h-6 w-6 text-primary" />
        <span className="ml-2 text-lg font-semibold">Enteteye Academy</span>
      </Link>
      <nav className="ml-auto hidden md:flex items-center gap-4 sm:gap-6">
        <Link href="/courses" className="text-sm font-medium hover:underline underline-offset-4" prefetch={false}>
          Courses
        </Link>
        <Link href="/#features" className="text-sm font-medium hover:underline underline-offset-4" prefetch={false}>
          Features
        </Link>
        <div className="flex items-center gap-4">
          <Button asChild variant="ghost">
            <Link href="/login">Login</Link>
          </Button>
          <Button asChild>
            <Link href="/signup">Sign Up</Link>
          </Button>
        </div>
      </nav>
      <div className="ml-auto md:hidden">
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="outline" size="icon">
              <Menu className="h-6 w-6" />
              <span className="sr-only">Open navigation menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="right">
            <div className="grid gap-4 p-4">
              <Link href="/" className="flex items-center justify-center mb-4" prefetch={false}>
                <AppLogo className="h-6 w-6 text-primary" />
                <span className="ml-2 text-lg font-semibold">Enteteye Academy</span>
              </Link>
              <Link href="/courses" className="text-base font-medium hover:underline underline-offset-4" prefetch={false}>
                Courses
              </Link>
              <Link href="/#features" className="text-base font-medium hover:underline underline-offset-4" prefetch={false}>
                Features
              </Link>
              <div className="flex flex-col gap-4 mt-4">
                <Button asChild variant="ghost">
                  <Link href="/login">Login</Link>
                </Button>
                <Button asChild>
                  <Link href="/signup">Sign Up</Link>
                </Button>
              </div>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  );
}
