import type { SVGProps } from 'react';
import { BookOpenCheck } from 'lucide-react';

export function AppLogo(props: SVGProps<SVGSVGElement>) {
  return <BookOpenCheck {...props} />;
}
