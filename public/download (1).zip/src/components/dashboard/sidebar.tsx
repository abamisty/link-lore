
'use client';

import * as React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  SidebarProvider,
  Sidebar,
  SidebarHeader,
  SidebarContent,
  SidebarTrigger,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarInset,
} from '@/components/ui/sidebar';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Bell, Book, LayoutDashboard, Settings, Users, LifeBuoy, LogOut, BarChart3, BotMessageSquare, BookHeart, Gamepad2, Smile } from 'lucide-react';
import { AppLogo } from '@/components/icons';

type NavItem = {
  href: string;
  icon: React.ElementType;
  label: string;
};

const studentNav: NavItem[] = [
  { href: '/student/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { href: '/courses', icon: Book, label: 'My Courses' },
  { href: '/student/progress', icon: BarChart3, label: 'My Progress' },
];

const parentNav: NavItem[] = [
  { href: '/parent/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { href: '/parent/children', icon: Users, label: 'My Children' },
  { href: '/courses', icon: Book, label: 'Course Library' },
  { href: '/parent/custom-courses', icon: BookHeart, label: 'Custom Courses' },
];

const adminNav: NavItem[] = [
  { href: '/admin/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { href: '/admin/users', icon: Users, label: 'Manage Users' },
  { href: '/admin/courses', icon: Book, label: 'Manage Courses' },
  { href: '/admin/activities', icon: Gamepad2, label: 'Activities' },
  { href: '/admin/characters', icon: Smile, label: 'Characters' },
];


const navItems: Record<string, NavItem[]> = {
  student: studentNav,
  parent: parentNav,
  admin: adminNav,
};

export function DashboardLayout({ children, role }: { children: React.ReactNode, role: 'student' | 'parent' | 'admin' }) {
  const pathname = usePathname();
  const currentNav = navItems[role];
  const pageTitle = currentNav.find(item => pathname.startsWith(item.href))?.label || `${role.charAt(0).toUpperCase() + role.slice(1)} Dashboard`;

  return (
    <SidebarProvider>
      <Sidebar>
        <SidebarHeader>
            <div className="flex items-center gap-2">
                <AppLogo className="size-6 text-primary" />
                <span className="text-lg font-semibold whitespace-nowrap">Enteteye Academy</span>
            </div>
        </SidebarHeader>
        <SidebarContent>
          <SidebarMenu>
            {currentNav.map((item) => (
              <SidebarMenuItem key={item.href}>
                <SidebarMenuButton asChild isActive={pathname === item.href || (item.href !== '/admin/dashboard' && item.href !== '/parent/dashboard' && item.href !== '/student/dashboard' && pathname.startsWith(item.href))}>
                  <Link href={item.href}>
                    <item.icon />
                    <span>{item.label}</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
            ))}
          </SidebarMenu>
        </SidebarContent>
      </Sidebar>
      <SidebarInset>
        <header className="flex h-16 items-center justify-between border-b bg-card px-4 md:px-6">
          <div className="flex items-center gap-4">
             <SidebarTrigger className="md:hidden" />
             <h1 className="text-lg font-semibold md:text-xl">{pageTitle}</h1>
          </div>
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" className="rounded-full">
              <Bell className="h-5 w-5" />
              <span className="sr-only">Toggle notifications</span>
            </Button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="secondary" size="icon" className="rounded-full">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src="https://placehold.co/100x100.png" alt="@user" />
                    <AvatarFallback>{role.charAt(0).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <span className="sr-only">Toggle user menu</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>My Account</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                  <Settings className="mr-2 h-4 w-4" />
                  <span>Settings</span>
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <LifeBuoy className="mr-2 h-4 w-4" />
                  <span>Support</span>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link href="/login">
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Logout</span>
                  </Link>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>
        <main className="flex-1 p-4 md:p-6 lg:p-8 bg-background/50">
            {children}
        </main>
      </SidebarInset>
    </SidebarProvider>
  );
}
