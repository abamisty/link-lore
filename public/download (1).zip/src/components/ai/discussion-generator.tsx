'use client';

import { useActionState } from 'react';
import { useFormStatus } from 'react-dom';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { generateDiscussionPointsAction } from '@/app/actions/generate-discussion-points';
import { Bot, Loader2, Sparkles } from 'lucide-react';

const initialState = {
  discussionPoints: '',
  error: null,
};

function SubmitButton() {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" className="w-full" disabled={pending}>
      {pending ? (
        <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Generating...
        </>
      ) : (
        <>
            <Sparkles className="mr-2 h-4 w-4" />
            Generate Discussion
        </>
      )}
    </Button>
  );
}

export function DiscussionGenerator() {
  const [state, formAction] = useActionState(generateDiscussionPointsAction, initialState);

  return (
    <Card className="sticky top-8">
      <form action={formAction}>
        <CardHeader>
          <div className="flex items-center gap-3">
            <div className="p-2 bg-primary/10 rounded-full">
                <Bot className="h-6 w-6 text-primary" />
            </div>
            <div>
              <CardTitle>AI Family Discussion Prompts</CardTitle>
              <CardDescription>
                Generate prompts to discuss a lesson with your child.
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="lessonSummary">Lesson Summary</Label>
            <Textarea
              id="lessonSummary"
              name="lessonSummary"
              placeholder="e.g., Alex learned about being kind to new students."
              required
              rows={3}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="keyAreas">Key Comprehension Areas</Label>
            <Textarea
              id="keyAreas"
              name="keyAreas"
              placeholder="e.g., Understanding why someone might feel lonely."
              required
              rows={2}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="familyValues">Family Values</Label>
            <Textarea
              id="familyValues"
              name="familyValues"
              placeholder="e.g., Compassion, helping others, being inclusive."
              required
              rows={2}
            />
          </div>
        </CardContent>
        <CardFooter className='flex-col items-start gap-4'>
            <SubmitButton />
            {state?.discussionPoints && (
            <Card className="w-full bg-secondary/50">
                <CardHeader>
                    <CardTitle className='text-base'>Generated Points</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="prose prose-sm max-w-none whitespace-pre-wrap">
                        {state.discussionPoints}
                    </div>
                </CardContent>
            </Card>
            )}
            {state?.error && (
                <p className="text-sm text-destructive">{state.error}</p>
            )}
        </CardFooter>
      </form>
    </Card>
  );
}
