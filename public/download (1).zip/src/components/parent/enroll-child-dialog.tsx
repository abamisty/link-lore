
'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { Loader2, UserPlus } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '../ui/label';

const childrenData = [
    { name: "Alex" },
    { name: "Benny" }
];

interface EnrollChildDialogProps {
    courseTitle: string;
}

export function EnrollChildDialog({ courseTitle }: EnrollChildDialogProps) {
  const [open, setOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedChild, setSelectedChild] = useState('');
  const { toast } = useToast();

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!selectedChild) {
        toast({
            title: 'Error',
            description: 'Please select a child to enroll.',
            variant: 'destructive',
        });
        return;
    }
    setIsSubmitting(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));

    setIsSubmitting(false);
    setOpen(false);
    toast({
        title: 'Success!',
        description: `${selectedChild} has been enrolled in "${courseTitle}".`,
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="w-full">
          <UserPlus />
          Enroll a Child
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Enroll in: {courseTitle}</DialogTitle>
          <DialogDescription>
            Select which child you would like to enroll in this course.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
             <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="childName" className="text-right">Child</Label>
                <div className="col-span-3">
                    <Select name="childName" required onValueChange={setSelectedChild}>
                        <SelectTrigger id="childName">
                            <SelectValue placeholder="Select your child" />
                        </SelectTrigger>
                        <SelectContent>
                            {childrenData.map(child => (
                                <SelectItem key={child.name} value={child.name}>{child.name}</SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </div>
            </div>
          </div>
          <DialogFooter>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Confirm Enrollment
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

    