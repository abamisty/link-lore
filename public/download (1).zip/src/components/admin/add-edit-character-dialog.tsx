
'use client';

import { useState, useEffect, type FormEvent, useRef } from 'react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Slider } from '@/components/ui/slider';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Loader2, Upload } from 'lucide-react';
import { type Character } from '@/app/admin/characters/page';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';

interface AddEditCharacterDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  character: Character | null;
  onSave: (characterData: Omit<Character, 'id'>) => void;
}

const defaultCharacterData: Omit<Character, 'id'> = {
    name: '',
    description: '',
    type: 'Human',
    age: 'adult',
    avatar: 'https://placehold.co/100x100.png?text=:)',
    personalityTraits: [],
    voiceSettings: {
        pitch: 50,
        speed: 50,
        tone: 'Friendly',
    },
    visualCustomization: {
        colorScheme: 'blue',
        outfit: 'casual',
        accessories: [],
    },
};

const personalityTraitsList = ['Friendly', 'Energetic', 'Humorous', 'Creative', 'Wise', 'Calm', 'Serious', 'Analytical'];
const accessoriesList = ['hat', 'glasses', 'jewelry', 'cape', 'backpack', 'staff'];
const colorSchemes = ['blue', 'green', 'purple', 'red', 'orange', 'pink'];

export function AddEditCharacterDialog({ open, onOpenChange, character, onSave }: AddEditCharacterDialogProps) {
  const [formData, setFormData] = useState(defaultCharacterData);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    if (open) {
      setFormData(character ? JSON.parse(JSON.stringify(character)) : defaultCharacterData);
    }
  }, [character, open]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name: 'type' | 'age' | 'tone' | 'outfit', value: string) => {
    if (name === 'tone') {
        setFormData(prev => ({ ...prev, voiceSettings: { ...prev.voiceSettings, tone: value } }));
    } else if (name === 'outfit') {
        setFormData(prev => ({ ...prev, visualCustomization: { ...prev.visualCustomization, outfit: value } }));
    } else {
        setFormData(prev => ({ ...prev, [name]: value as any }));
    }
  };
  
  const handleTraitChange = (trait: string, checked: boolean) => {
    setFormData(prev => {
        const traits = checked
            ? [...prev.personalityTraits, trait]
            : prev.personalityTraits.filter(t => t !== trait);
        return { ...prev, personalityTraits: traits };
    });
  };

  const handleAccessoryChange = (accessory: string, checked: boolean) => {
     setFormData(prev => {
        const accessories = checked
            ? [...prev.visualCustomization.accessories, accessory]
            : prev.visualCustomization.accessories.filter(a => a !== accessory);
        return { ...prev, visualCustomization: {...prev.visualCustomization, accessories } };
    });
  }
  
  const handleSliderChange = (name: 'pitch' | 'speed', value: number[]) => {
    setFormData(prev => ({
      ...prev,
      voiceSettings: {
        ...prev.voiceSettings,
        [name]: value[0],
      },
    }));
  };
  
  const handleColorChange = (color: string) => {
    setFormData(prev => ({
      ...prev,
      visualCustomization: {
        ...prev.visualCustomization,
        colorScheme: color,
      },
    }));
  }

  const handleAvatarUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) { // 2MB limit
          toast({
              title: "File too large",
              description: "Please select an image smaller than 2MB.",
              variant: "destructive"
          });
          return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, avatar: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (event: FormEvent) => {
    event.preventDefault();
    setIsSubmitting(true);
    
    setTimeout(() => {
      onSave(formData);
      setIsSubmitting(false);
      onOpenChange(false);
    }, 1000);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] flex flex-col">
        <DialogHeader>
          <DialogTitle>{character ? 'Edit Character' : 'Create New Character'}</DialogTitle>
        </DialogHeader>
        <form id="character-form" onSubmit={handleSubmit} className="flex-1 overflow-y-auto pr-6 -mr-6 pl-1 -ml-1">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
            {/* Left Column */}
            <div className="space-y-6">
              <div className="space-y-2">
                  <Label>Avatar</Label>
                  <div className="flex items-center gap-4">
                      <Avatar className="h-20 w-20">
                          <AvatarImage src={formData.avatar} />
                          <AvatarFallback>{formData.name ? formData.name.charAt(0) : '?'}</AvatarFallback>
                      </Avatar>
                      <input
                        type="file"
                        ref={fileInputRef}
                        onChange={handleAvatarUpload}
                        className="hidden"
                        accept="image/png, image/jpeg, image/gif"
                      />
                      <Button type="button" variant="outline" onClick={() => fileInputRef.current?.click()}>
                        <Upload className="mr-2 h-4 w-4" />
                        Upload Image
                      </Button>
                  </div>
              </div>
              <div className="space-y-2">
                  <Label htmlFor="name">Name</Label>
                  <Input id="name" name="name" placeholder="Enter character name" value={formData.name} onChange={handleInputChange} required />
              </div>
              <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea id="description" name="description" placeholder="Describe your character..." value={formData.description} onChange={handleInputChange} rows={4} />
              </div>
               <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="type">Type</Label>
                    <Select name="type" required value={formData.type} onValueChange={(v) => handleSelectChange('type', v)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Human">Human</SelectItem>
                        <SelectItem value="Animal">Animal</SelectItem>
                        <SelectItem value="Robot">Robot</SelectItem>
                        <SelectItem value="Other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="age">Age Group</Label>
                    <Select name="age" required value={formData.age} onValueChange={(v) => handleSelectChange('age', v)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="child">Child</SelectItem>
                        <SelectItem value="teen">Teen</SelectItem>
                        <SelectItem value="adult">Adult</SelectItem>
                        <SelectItem value="senior">Senior</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
            </div>

            {/* Right Column */}
            <div className="space-y-6">
                 <div className="p-4 border rounded-md space-y-4">
                     <Label>Personality Traits</Label>
                     <ScrollArea className="h-32">
                        <div className="grid grid-cols-2 gap-4">
                            {personalityTraitsList.map(trait => (
                                <div key={trait} className="flex items-center space-x-2">
                                    <Checkbox 
                                        id={`trait-${trait}`}
                                        checked={(formData.personalityTraits || []).includes(trait)}
                                        onCheckedChange={(checked) => handleTraitChange(trait, !!checked)}
                                    />
                                    <Label htmlFor={`trait-${trait}`} className="font-normal">{trait}</Label>
                                </div>
                            ))}
                        </div>
                     </ScrollArea>
                </div>

                <div className="p-4 border rounded-md space-y-4">
                    <Label>Voice Settings</Label>
                    <div className="space-y-2">
                        <Label htmlFor="pitch" className="text-sm">Pitch: {formData.voiceSettings.pitch}</Label>
                        <Slider id="pitch" value={[formData.voiceSettings.pitch]} onValueChange={(v) => handleSliderChange('pitch', v)} />
                    </div>
                     <div className="space-y-2">
                        <Label htmlFor="speed" className="text-sm">Speed: {formData.voiceSettings.speed}</Label>
                        <Slider id="speed" value={[formData.voiceSettings.speed]} onValueChange={(v) => handleSliderChange('speed', v)} />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="tone">Tone</Label>
                        <Select name="tone" value={formData.voiceSettings.tone} onValueChange={(v) => handleSelectChange('tone', v)}>
                           <SelectTrigger><SelectValue /></SelectTrigger>
                           <SelectContent>
                               <SelectItem value="Friendly">Friendly</SelectItem>
                               <SelectItem value="Calm">Calm</SelectItem>
                               <SelectItem value="Serious">Serious</SelectItem>
                           </SelectContent>
                        </Select>
                    </div>
                </div>

                <div className="p-4 border rounded-md space-y-4">
                    <Label>Visual Customization</Label>
                    <div className="space-y-2">
                        <Label className="text-sm">Color Scheme</Label>
                        <div className="flex gap-2">
                            {colorSchemes.map(color => (
                                <button key={color} type="button" onClick={() => handleColorChange(color)} className={cn("w-6 h-6 rounded-full border-2", formData.visualCustomization.colorScheme === color ? 'border-ring' : 'border-transparent')} style={{backgroundColor: color}} />
                            ))}
                        </div>
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="outfit">Outfit</Label>
                        <Select name="outfit" value={formData.visualCustomization.outfit} onValueChange={(v) => handleSelectChange('outfit', v)}>
                           <SelectTrigger><SelectValue /></SelectTrigger>
                           <SelectContent>
                               <SelectItem value="casual">Casual</SelectItem>
                               <SelectItem value="formal">Formal</SelectItem>
                               <SelectItem value="uniform">Uniform</SelectItem>
                           </SelectContent>
                        </Select>
                    </div>
                    <div className="space-y-2">
                        <Label>Accessories</Label>
                        <div className="grid grid-cols-3 gap-4">
                            {accessoriesList.map(acc => (
                                <div key={acc} className="flex items-center space-x-2">
                                     <Checkbox 
                                        id={`acc-${acc}`}
                                        checked={(formData.visualCustomization.accessories || []).includes(acc)}
                                        onCheckedChange={(checked) => handleAccessoryChange(acc, !!checked)}
                                    />
                                    <Label htmlFor={`acc-${acc}`} className="font-normal capitalize">{acc}</Label>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
          </div>
        </form>
         <DialogFooter className="pt-6">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button type="submit" form="character-form" disabled={isSubmitting}>
              {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {character ? 'Save Changes' : 'Create Character'}
            </Button>
          </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
