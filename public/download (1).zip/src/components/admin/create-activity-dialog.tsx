
'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { PlusCircle, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Textarea } from '@/components/ui/textarea';
import type { Activity } from '@/app/admin/activities/page';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface CreateActivityDialogProps {
  onActivityCreated: (activity: Omit<Activity, 'id' | 'dateCreated'>) => void;
}

const activityTypes = [
    'Accordion',
    'Branching Scenario',
    'Course presentation',
    'Drag and Drop',
    'Drag the Words',
    'Fill in the Blanks',
    'Interactive Book',
    'Interactive Dialogue',
    'Interactive Video',
    'Multiple Choice',
    'Question Set',
    'Scenario',
    'Story telling',
    'Values Sorting',
];

export function CreateActivityDialog({ onActivityCreated }: CreateActivityDialogProps) {
  const [open, setOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();
  const [selectedType, setSelectedType] = useState('');

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setIsSubmitting(true);
    
    const formData = new FormData(event.currentTarget);
    const title = formData.get('title') as string;
    const instructions = formData.get('instructions') as string;
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));

    const newActivity = {
        title,
        type: selectedType,
        instructions,
        status: 'Draft' as const
    };

    onActivityCreated(newActivity);

    setIsSubmitting(false);
    setOpen(false);
    (event.target as HTMLFormElement).reset();
    toast({
        title: 'Activity Created!',
        description: `"${title}" has been added as a draft. You can now edit it to add content.`,
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <PlusCircle />
          Create Activity
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[525px]">
        <DialogHeader>
          <DialogTitle>Create New Activity</DialogTitle>
          <DialogDescription>
            Choose an activity type and give it a title to get started.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="title" className="text-right">
                Title
              </Label>
              <Input id="title" name="title" required className="col-span-3" placeholder="e.g., The Playground Dilemma" />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="type" className="text-right">
                Type
              </Label>
               <Select name="type" required onValueChange={setSelectedType}>
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Select activity type" />
                </SelectTrigger>
                <SelectContent>
                    {activityTypes.sort().map(type => (
                        <SelectItem key={type} value={type}>{type}</SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-start gap-4">
               <Label htmlFor="instructions" className="text-right pt-2">
                Instructions
              </Label>
              <Textarea id="instructions" name="instructions" placeholder="Optional instructions for the student." className="col-span-3" />
            </div>
          </div>
          <DialogFooter>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Create Draft
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

    