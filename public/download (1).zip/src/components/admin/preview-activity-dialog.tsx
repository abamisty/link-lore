
'use client';

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import type { Activity } from '@/app/admin/activities/page';

interface PreviewActivityDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  activity: Activity;
}

export function PreviewActivityDialog({ open, onOpenChange, activity }: PreviewActivityDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-4xl h-[80vh] flex flex-col">
        <DialogHeader>
          <DialogTitle>Preview: {activity.title}</DialogTitle>
          <DialogDescription>
            {activity.instructions}
          </DialogDescription>
        </DialogHeader>
        <div className="flex-1 w-full h-full border rounded-md overflow-hidden">
            <iframe
                src={activity.embedUrl}
                className="w-full h-full border-0"
                title={activity.title}
                allowFullScreen
                allow="autoplay *; geolocation *; microphone *; camera *; midi *; encrypted-media *"
            ></iframe>
        </div>
      </DialogContent>
    </Dialog>
  );
}
