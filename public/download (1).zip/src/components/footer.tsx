import Link from 'next/link';
import { AppLogo } from '@/components/icons';
import { Twitter, Facebook, Linkedin } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-card border-t py-6">
      <div className="container mx-auto px-4 md:px-6 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center">
          <AppLogo className="h-6 w-6 text-primary" />
          <span className="ml-2 text-lg font-semibold">Enteteye Academy</span>
        </div>
        <nav className="flex flex-wrap items-center justify-center gap-4 sm:gap-6 text-sm">
          <Link href="/courses" className="font-medium hover:underline underline-offset-4" prefetch={false}>
            Courses
          </Link>
          <Link href="/about" className="font-medium hover:underline underline-offset-4" prefetch={false}>
            About Us
          </Link>
          <Link href="/contact" className="font-medium hover:underline underline-offset-4" prefetch={false}>
            Contact
          </Link>
          <Link href="/privacy" className="font-medium hover:underline underline-offset-4" prefetch={false}>
            Privacy Policy
          </Link>
        </nav>
        <div className="flex items-center gap-4">
          <Link href="#" aria-label="Twitter">
            <Twitter className="h-5 w-5 text-muted-foreground hover:text-primary" />
          </Link>
          <Link href="#" aria-label="Facebook">
            <Facebook className="h-5 w-5 text-muted-foreground hover:text-primary" />
          </Link>
          <Link href="#" aria-label="LinkedIn">
            <Linkedin className="h-5 w-5 text-muted-foreground hover:text-primary" />
          </Link>
        </div>
      </div>
       <div className="text-center text-sm text-muted-foreground mt-6 px-4">
          © {new Date().getFullYear()} Enteteye Academy. All rights reserved.
        </div>
    </footer>
  );
}
