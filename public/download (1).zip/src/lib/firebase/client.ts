// This file is intentionally left blank as Firebase is not configured for the demo.
export {};
